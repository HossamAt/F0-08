package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status, selected, dot;
    private Button toggle;
    private SeekBar intensity, contrast, saturation, brightness, warmth;
    private boolean running = false;

    static class Filter {
        String name, ar;
        int r,g,b,a,c,s,br,w;
        Filter(String name,String ar,int r,int g,int b,int a,int c,int s,int br,int w){
            this.name=name; this.ar=ar; this.r=r; this.g=g; this.b=b; this.a=a;
            this.c=c; this.s=s; this.br=br; this.w=w;
        }
    }

    private final Filter[] filters = {
        new Filter("NIGHT", "ليل سينمائي", 18,42,95,92,76,64,45,30),
        new Filter("SUNSET", "غروب ذهبي", 220,92,24,76,68,78,58,88),
        new Filter("MORNING", "صباح فيلمي", 255,210,150,52,52,60,68,72),
        new Filter("GTA", "سينمائي", 76,42,24,74,82,78,50,48),
        new Filter("DARK", "مدينة داكنة", 8,14,28,100,88,55,38,28),
        new Filter("EMERALD", "ليل زمردي", 14,112,76,86,78,82,43,28),
        new Filter("FIRE", "شوارع حارة", 178,46,18,76,82,84,50,90),
        new Filter("COLD", "مدينة باردة", 24,78,145,82,74,64,48,20),
        new Filter("GOLD", "الساعة الذهبية", 238,156,52,66,64,78,66,92),
        new Filter("MOVIE", "احترافي", 58,60,54,62,88,70,52,50),
        new Filter("CLEAR", "وضوح قوي", 86,92,110,34,94,66,56,50),
        new Filter("FILM", "فيلم قديم", 118,82,48,66,62,68,48,65)
    };

    private int r=18,g=42,b=95,a=92;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(7,9,14));
        w.setNavigationBarColor(Color.rgb(7,9,14));
        if (Build.VERSION.SDK_INT >= 23) {
            w.getDecorView().setSystemUiVisibility(0);
        }
        buildUi();
        choose(filters[0]);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        return t;
    }

    private LinearLayout.LayoutParams lp(int width,int height,int top,int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width,height);
        p.setMargins(0,top,0,bottom);
        return p;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(7,9,14));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP);
        root.setPadding(18,18,18,30);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView brand = text("HOSSAM", 31, Color.rgb(0,220,255));
        brand.setTypeface(null,1);
        brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(brand, lp(-1,44,0,0));

        TextView title = text("OneState Filters", 25, Color.WHITE);
        title.setTypeface(null,1);
        title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(title, lp(-1,40,0,2));

        TextView sub = text("فلاتر سينمائية احترافية لتصوير OneState", 13, Color.rgb(150,160,175));
        sub.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(sub, lp(-1,30,0,14));

        LinearLayout state = new LinearLayout(this);
        state.setGravity(Gravity.CENTER_VERTICAL);
        state.setPadding(14,5,14,5);
        state.setBackground(bg(Color.rgb(17,23,32),22));
        state.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        dot = text("●",20,Color.rgb(255,80,90));
        dot.setGravity(Gravity.CENTER);
        state.addView(dot, new LinearLayout.LayoutParams(35,55));

        LinearLayout stateText = new LinearLayout(this);
        stateText.setOrientation(LinearLayout.VERTICAL);
        stateText.setGravity(Gravity.CENTER_VERTICAL);
        status = text("الفلاتر متوقفة",16,Color.WHITE);
        status.setTypeface(null,1);
        status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        stateText.addView(status);
        TextView hint = text("اختر فلترًا ثم اضغط تشغيل",12,Color.rgb(145,153,166));
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        stateText.addView(hint);
        state.addView(stateText,new LinearLayout.LayoutParams(0,58,1));
        root.addView(state,lp(-1,70,0,10));

        LinearLayout permission = new LinearLayout(this);
        permission.setGravity(Gravity.CENTER_VERTICAL);
        permission.setPadding(12,4,8,4);
        permission.setBackground(bg(Color.rgb(13,18,26),20));
        permission.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView pt = text("الظهور فوق التطبيقات",14,Color.WHITE);
        pt.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        permission.addView(pt,new LinearLayout.LayoutParams(0,50,1));

        Button manage = new Button(this);
        manage.setText("إدارة الصلاحية");
        manage.setTextSize(12);
        manage.setAllCaps(false);
        manage.setTextColor(Color.rgb(0,220,255));
        manage.setBackground(bg(Color.rgb(24,36,48),17));
        manage.setOnClickListener(v -> openOverlaySettings());
        permission.addView(manage,new LinearLayout.LayoutParams(130,50));
        root.addView(permission,lp(-1,62,0,10));

        toggle = new Button(this);
        toggle.setText("تشغيل الفلتر");
        toggle.setTextSize(18);
        toggle.setAllCaps(false);
        toggle.setTypeface(null,1);
        toggle.setTextColor(Color.WHITE);
        toggle.setBackground(bg(Color.rgb(0,150,185),23));
        toggle.setOnClickListener(v -> toggleOverlay());
        root.addView(toggle,lp(-1,62,0,18));

        TextView fh = text("الفلاتر الجاهزة",19,Color.WHITE);
        fh.setTypeface(null,1);
        fh.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(fh,lp(-1,34,0,4));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0,2,0,2);

        for (Filter f : filters) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(7,7,7,5);
            card.setBackground(bg(Color.rgb(21,28,39),18));

            View swatch = new View(this);
            swatch.setBackground(bg(Color.rgb(f.r,f.g,f.b),14));
            card.addView(swatch,new LinearLayout.LayoutParams(112,38));

            TextView name = text(f.name,10,Color.WHITE);
            name.setGravity(Gravity.CENTER);
            card.addView(name,new LinearLayout.LayoutParams(112,30));

            card.setOnClickListener(v -> choose(f));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(124,76);
            cp.setMargins(0,0,8,0);
            row.addView(card,cp);
        }
        hsv.addView(row);
        root.addView(hsv,new LinearLayout.LayoutParams(-1,86));

        selected = text("الفلتر الحالي",17,Color.rgb(0,220,255));
        selected.setTypeface(null,1);
        selected.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(selected,lp(-1,42,8,2));

        intensity = slider(root,"قوة الفلتر",78);
        contrast = slider(root,"التباين",70);
        saturation = slider(root,"التشبع",70);
        brightness = slider(root,"السطوع",55);
        warmth = slider(root,"الدفء",50);

        TextView note = text("الطبقة تعمل بكامل الشاشة ولا تستقبل اللمس، لذلك لن تمنع التحكم داخل OneState.",12,Color.rgb(145,153,166));
        note.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        note.setPadding(12,4,12,4);
        note.setBackground(bg(Color.rgb(13,18,26),18));
        root.addView(note,lp(-1,58,14,0));

        scroll.addView(root);
        setContentView(scroll);
    }

    private SeekBar slider(LinearLayout root,String label,int value) {
        TextView l = text(label,13,Color.rgb(205,212,222));
        l.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(l,lp(-1,25,7,0));

        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b,int p,boolean fromUser) {
                if (running) sendUpdate();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        root.addView(s,lp(-1,38,0,0));
        return s;
    }

    private void choose(Filter f) {
        r=f.r; g=f.g; b=f.b; a=f.a;
        selected.setText("الفلتر الحالي  •  "+f.name+"  —  "+f.ar);
        intensity.setProgress(78);
        contrast.setProgress(f.c);
        saturation.setProgress(f.s);
        brightness.setProgress(f.br);
        warmth.setProgress(f.w);
        if (running) sendUpdate();
    }

    private void sendUpdate() {
        if (!running) return;
        Intent i = new Intent(this,OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        i.putExtra("r",r); i.putExtra("g",g); i.putExtra("b",b); i.putExtra("alpha",a);
        i.putExtra("intensity",intensity.getProgress());
        i.putExtra("contrast",contrast.getProgress());
        i.putExtra("saturation",saturation.getProgress());
        i.putExtra("brightness",brightness.getProgress());
        i.putExtra("warmth",warmth.getProgress());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            return;
        }

        if (!running) {
            running=true;
            toggle.setText("إيقاف الفلتر");
            toggle.setBackground(bg(Color.rgb(190,48,65),23));
            status.setText("الفلاتر تعمل الآن");
            dot.setTextColor(Color.rgb(60,235,140));
            sendUpdate();
        } else {
            running=false;
            toggle.setText("تشغيل الفلتر");
            toggle.setBackground(bg(Color.rgb(0,150,185),23));
            status.setText("الفلاتر متوقفة");
            dot.setTextColor(Color.rgb(255,80,90));
            stopService(new Intent(this,OverlayService.class));
        }
    }

    private void openOverlaySettings() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:"+getPackageName()));
        startActivity(i);
    }
}
