package com.hossam.onestatefilters;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.graphics.PixelFormat;

public class OverlayService extends Service {
    public static final String ACTION_UPDATE = "com.hossam.onestatefilters.UPDATE";
    private static final String CHANNEL = "hossam_filters";

    private WindowManager wm;
    private FilterView filterView;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(77, notification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(77, notification());
        }

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createOverlay();
    }

    private void createOverlay() {
        if (filterView != null) return;

        filterView = new FilterView();
        filterView.setAlpha(1f);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.RGBA_8888
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;
        params.setTitle("Hossam OneState Filter");

        try {
            wm.addView(filterView,params);
        } catch (Exception e) {
            filterView = null;
            stopSelf();
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (filterView == null) createOverlay();

        if (intent != null && ACTION_UPDATE.equals(intent.getAction()) && filterView != null) {
            filterView.setValues(
                    intent.getIntExtra("r",18),
                    intent.getIntExtra("g",42),
                    intent.getIntExtra("b",95),
                    intent.getIntExtra("alpha",92),
                    intent.getIntExtra("intensity",78),
                    intent.getIntExtra("contrast",70),
                    intent.getIntExtra("saturation",70),
                    intent.getIntExtra("brightness",55),
                    intent.getIntExtra("warmth",50)
            );
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL,"Hossam Filters",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Hossam OneState full-screen filter");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this,MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this,0,open,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);

        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this,CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .setContentTitle("Hossam OneState Filters")
                    .setContentText("فلتر الشاشة يعمل الآن")
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Hossam OneState Filters")
                .setContentText("فلتر الشاشة يعمل الآن")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        if (wm != null && filterView != null) {
            try { wm.removeViewImmediate(filterView); } catch(Exception ignored) {}
        }
        filterView=null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private class FilterView extends View {
        private int r=18,g=42,b=95,a=92,intensity=78,contrast=70,saturation=70,brightness=55,warmth=50;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FilterView() {
            super(OverlayService.this);
            setLayerType(View.LAYER_TYPE_HARDWARE,null);
            setWillNotDraw(false);
        }

        void setValues(int r,int g,int b,int a,int intensity,int contrast,int saturation,int brightness,int warmth) {
            this.r=r; this.g=g; this.b=b; this.a=a;
            this.intensity=intensity; this.contrast=contrast;
            this.saturation=saturation; this.brightness=brightness; this.warmth=warmth;
            postInvalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float strength = Math.max(0.08f, Math.min(1f,intensity/100f));
            int tintAlpha = Math.max(24, Math.min(185,(int)(a*strength)));

            // Main cinematic tint.
            canvas.drawColor(Color.argb(tintAlpha,r,g,b));

            // Brightness lift / reduction.
            int brightDelta = brightness - 50;
            if (brightDelta != 0) {
                int ba = Math.min(75,Math.abs(brightDelta));
                if (brightDelta > 0) {
                    canvas.drawColor(Color.argb((int)(ba*0.55f),255,255,255));
                } else {
                    canvas.drawColor(Color.argb((int)(ba*0.60f),0,0,0));
                }
            }

            // Warm/cool film wash.
            float warm=(warmth-50)/50f;
            if (warm > 0.02f) {
                canvas.drawColor(Color.argb((int)(58*warm*strength),255,132,40));
            } else if (warm < -0.02f) {
                canvas.drawColor(Color.argb((int)(58*(-warm)*strength),45,115,255));
            }

            // Contrast vignette.
            int vignetteAlpha=Math.max(0,Math.min(145,(int)((contrast-20)*1.35f)));
            int w=getWidth(), h=getHeight();
            if (w>0 && h>0 && vignetteAlpha>0) {
                RadialGradient gradient=new RadialGradient(
                        w/2f,h/2f,Math.max(w,h)*0.78f,
                        new int[]{Color.TRANSPARENT,Color.argb(vignetteAlpha,0,0,0)},
                        new float[]{0.45f,1f},Shader.TileMode.CLAMP);
                paint.setShader(gradient);
                canvas.drawRect(0,0,w,h,paint);
                paint.setShader(null);
            }
        }
    }
}
