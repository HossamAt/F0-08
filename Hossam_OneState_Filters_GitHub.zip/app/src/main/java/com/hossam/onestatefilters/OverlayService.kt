package com.hossam.onestatefilters

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var filterView: View? = null
    private var panel: LinearLayout? = null

    private data class Filter(val name: String, val color: Int, val alpha: Int)

    private val filters = listOf(
        Filter("🌃 Night Cinematic", Color.rgb(25, 55, 95), 48),
        Filter("🌇 Sunset Gold", Color.rgb(210, 105, 35), 42),
        Filter("🌅 Morning Film", Color.rgb(255, 220, 165), 28),
        Filter("🎥 GTA Cinematic", Color.rgb(75, 45, 30), 34),
        Filter("🖤 Dark Urban", Color.rgb(15, 20, 28), 55),
        Filter("🟢 Emerald Night", Color.rgb(20, 105, 75), 40),
        Filter("🔥 Street Fire", Color.rgb(155, 55, 25), 35),
        Filter("❄️ Cold City", Color.rgb(35, 80, 130), 38),
        Filter("☀️ Golden Hour", Color.rgb(235, 165, 70), 35),
        Filter("📽️ Movie Pro", Color.rgb(65, 65, 55), 28),
        Filter("💎 Ultra Sharp", Color.TRANSPARENT, 0),
        Filter("🎞️ Film 90s", Color.rgb(115, 85, 55), 30)
    )

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(type: Int, w: Int, h: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

    private fun showBubble() {
        val bubble = TextView(this).apply {
            text = "H"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(10, 30, 40))
            setPadding(18, 10, 18, 10)
            setOnClickListener { togglePanel() }
        }

        val p = params(
            if (android.os.Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            64, 64
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 16
        p.y = 220
        wm.addView(bubble, p)

        bubble.setOnTouchListener(DragTouchListener(bubble, p))
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel)
            panel = null
            return
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.argb(235, 10, 12, 18))
        }

        val title = TextView(this).apply {
            text = "HOSSAM  •  OneState Filters"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        }
        box.addView(title)

        filters.forEach { f ->
            val b = Button(this).apply {
                text = f.name
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(25, 28, 38))
                setOnClickListener { applyFilter(f) }
            }
            box.addView(b, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 48
            ).apply { bottomMargin = 5 })
        }

        val close = Button(this).apply {
            text = "إخفاء اللوحة"
            setOnClickListener {
                wm.removeView(box)
                panel = null
            }
        }
        box.addView(close)

        val p = params(
            if (android.os.Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            430, WindowManager.LayoutParams.WRAP_CONTENT
        )
        p.gravity = Gravity.CENTER
        wm.addView(box, p)
        panel = box
    }

    private fun applyFilter(f: Filter) {
        if (filterView != null) wm.removeView(filterView)

        if (f.alpha == 0) return

        val v = View(this).apply {
            setBackgroundColor(Color.argb(f.alpha, Color.red(f.color), Color.green(f.color), Color.blue(f.color)))
        }

        val p = params(
            if (android.os.Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        p.gravity = Gravity.CENTER
        // Let touch events pass through to OneState.
        p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        wm.addView(v, p)
        filterView = v
    }

    override fun onDestroy() {
        filterView?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class DragTouchListener(
        private val view: View,
        private val lp: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private var downX = 0
        private var downY = 0
        private var startX = 0
        private var startY = 0

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX.toInt()
                    downY = event.rawY.toInt()
                    startX = lp.x
                    startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX - (event.rawX.toInt() - downX)
                    lp.y = startY + (event.rawY.toInt() - downY)
                    lp.x = max(0, lp.x)
                    lp.y = max(0, lp.y)
                    return true
                }
            }
            return false
        }
    }
}
