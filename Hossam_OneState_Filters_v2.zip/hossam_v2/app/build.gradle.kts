plugins {
    id("com.android.application")
}

android {
    namespace = "com.hossam.onestatefilters"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hossam.onestatefilters"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
