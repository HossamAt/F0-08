package com.hossam.onestatefilters

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    companion object { const val ACTION_UPDATE="com.hossam.onestatefilters.UPDATE" }
    private lateinit var wm:WindowManager
    private var overlay:FilterView?=null
    override fun onCreate(){
        super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager
        overlay=FilterView(); val p=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,android.graphics.PixelFormat.TRANSLUCENT); p.gravity=Gravity.CENTER; wm.addView(overlay,p)
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { if(intent?.action==ACTION_UPDATE) overlay?.set(intent); return START_STICKY }
    override fun onDestroy(){ overlay?.let{try{wm.removeView(it)}catch(_:Exception){}}; overlay=null; super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
    inner class FilterView:View(this@OverlayService){
        var r=25;var g=55;var b=95;var base=65;var intensity=100f;var contrast=78f;var saturation=58f;var brightness=44f;var warmth=35f
        init{setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
        fun set(i:Intent){r=i.getIntExtra("r",r);g=i.getIntExtra("g",g);b=i.getIntExtra("b",b);base=i.getIntExtra("alpha",base);intensity=i.getFloatExtra("intensity",intensity);contrast=i.getFloatExtra("contrast",contrast);saturation=i.getFloatExtra("saturation",saturation);brightness=i.getFloatExtra("brightness",brightness);warmth=i.getFloatExtra("warmth",warmth);invalidate()}
        override fun onDraw(c:android.graphics.Canvas){
            val p=intensity/100f; val a=(base*p).toInt().coerceIn(0,180); c.drawColor(Color.argb(a,r,g,b))
            val w=(warmth-50f)/50f; if(kotlin.math.abs(w)>.04f){val wa=(32f*kotlin.math.abs(w)*p).toInt(); c.drawColor(if(w>0)Color.argb(wa,255,140,45) else Color.argb(wa,45,110,255))}
            val vig=(contrast-35f).coerceIn(0f,65f).toInt(); if(width>0&&height>0){val grad=RadialGradient(width/2f,height/2f,(kotlin.math.min(width,height)*.72f),intArrayOf(Color.TRANSPARENT,Color.argb(vig,0,0,0)),floatArrayOf(.48f,1f),Shader.TileMode.CLAMP);val paint=android.graphics.Paint();paint.shader=grad;c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint)}
        }
    }
}
