# Hossam OneState Filters

Android overlay filter app for OneState screen recording.

## Features
- Floating H button over other apps.
- Ready-made night, sunset, morning, cinematic and color filters.
- Full-screen transparent filter layer.
- Filter layer is not touchable, so OneState remains usable.
- GitHub Actions workflow builds a debug APK automatically.

## Important
This version uses an Android overlay color-grading layer. It does not modify OneState files or inject code into the game.
