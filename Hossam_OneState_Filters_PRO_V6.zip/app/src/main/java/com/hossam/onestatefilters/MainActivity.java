package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CYAN = Color.rgb(0,220,255);
    private static final int BG = Color.rgb(7,9,14);

    private TextView status, selectedTitle, selectedSub, dot;
    private Button mainToggle;
    private LinearLayout listContainer, detailContainer;
    private SeekBar intensity, contrast, saturation, brightness, warmth;
    private boolean running = false;
    private Filter current;

    static class Filter {
        final String name, ar, description;
        final int r,g,b,a,c,s,br,w;
        Filter(String name,String ar,String description,int r,int g,int b,int a,int c,int s,int br,int w){
            this.name=name; this.ar=ar; this.description=description;
            this.r=r; this.g=g; this.b=b; this.a=a;
            this.c=c; this.s=s; this.br=br; this.w=w;
        }
    }

    private final Filter[] filters = {
        new Filter("NIGHT CINEMATIC","ليل سينمائي","أزرق سينمائي عميق مناسب للمشاهد الليلية.",18,42,95,88,76,64,48,30),
        new Filter("SUNSET GOLD","غروب ذهبي","دفء برتقالي وذهبي لمشاهد الغروب.",220,92,24,72,68,78,58,88),
        new Filter("MORNING FILM","صباح فيلمي","إضاءة صباحية ناعمة مع دفء خفيف.",255,210,150,48,52,60,68,72),
        new Filter("GTA CINEMATIC","GTA سينمائي","مظهر سينمائي قوي مناسب للشوارع والمطاردات.",76,42,24,68,82,78,50,48),
        new Filter("DARK URBAN","مدينة داكنة","ألوان داكنة وتباين أعلى لمشهد حضري.",8,14,28,94,88,55,38,28),
        new Filter("EMERALD NIGHT","ليل زمردي","أخضر زمردي بارد للمشاهد الليلية.",14,112,76,82,78,82,43,28),
        new Filter("STREET FIRE","شوارع حارة","ألوان دافئة وقوية للقطات الحركة.",178,46,18,70,82,84,50,90),
        new Filter("COLD CITY","مدينة باردة","لون بارد ونظيف للمدينة ليلاً.",24,78,145,76,74,64,48,20),
        new Filter("GOLDEN HOUR","الساعة الذهبية","تدرج ذهبي سينمائي لمشاهد المساء.",238,156,52,62,64,78,66,92),
        new Filter("MOVIE PRO","Movie Pro","توازن سينمائي احترافي للاستخدام العام.",58,60,54,58,88,70,52,50),
        new Filter("ULTRA CLEAR","Ultra Clear","تباين قوي وإحساس أكثر وضوحاً.",86,92,110,30,94,66,56,50),
        new Filter("FILM 90s","فيلم 90s","طابع فيلمي دافئ مستوحى من الأفلام القديمة.",118,82,48,58,62,68,48,65)
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
        openFilter(filters[0]);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean serviceOn = OverlayService.isRunning(this);
        running = serviceOn;
        updateStateUi();
    }

    private GradientDrawable rounded(int color,float radius){
        GradientDrawable d=new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView tv(String s,float size,int color){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w,int h,int top,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);
        p.setMargins(0,top,0,bottom); return p;
    }

    private void build(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,16,18,28);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView brand=tv("HOSSAM",30,CYAN); brand.setTypeface(null,1);
        brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(brand,lp(-1,44,0,0));

        TextView title=tv("OneState Filters",24,Color.WHITE); title.setTypeface(null,1);
        title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(title,lp(-1,38,0,0));

        TextView sub=tv("تصوير سينمائي • فلاتر شاشة • تحكم كامل",12,Color.rgb(145,155,170));
        sub.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(sub,lp(-1,28,0,12));

        LinearLayout state=new LinearLayout(this);
        state.setGravity(Gravity.CENTER_VERTICAL);
        state.setPadding(12,5,12,5);
        state.setBackground(rounded(Color.rgb(17,23,32),20));

        dot=tv("●",20,Color.RED); dot.setGravity(Gravity.CENTER);
        state.addView(dot,new LinearLayout.LayoutParams(34,56));

        LinearLayout stateTexts=new LinearLayout(this);
        stateTexts.setOrientation(LinearLayout.VERTICAL);
        status=tv("الفلتر متوقف",15,Color.WHITE); status.setTypeface(null,1);
        status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        stateTexts.addView(status);
        TextView st=tv("الطبقة تعمل فوق اللعبة عند التفعيل",11,Color.rgb(145,153,166));
        st.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        stateTexts.addView(st);
        state.addView(stateTexts,new LinearLayout.LayoutParams(0,58,1));
        root.addView(state,lp(-1,68,0,9));

        LinearLayout perm=new LinearLayout(this);
        perm.setGravity(Gravity.CENTER_VERTICAL);
        perm.setPadding(10,4,7,4);
        perm.setBackground(rounded(Color.rgb(13,18,26),18));

        TextView ptext=tv("صلاحية الظهور فوق التطبيقات",13,Color.WHITE);
        ptext.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        perm.addView(ptext,new LinearLayout.LayoutParams(0,50,1));

        Button pbtn=new Button(this);
        pbtn.setText("إدارة");
        pbtn.setAllCaps(false);
        pbtn.setTextSize(12);
        pbtn.setTextColor(CYAN);
        pbtn.setBackground(rounded(Color.rgb(24,36,48),16));
        pbtn.setOnClickListener(v->openOverlaySettings());
        perm.addView(pbtn,new LinearLayout.LayoutParams(90,50));
        root.addView(perm,lp(-1,60,0,10));

        mainToggle=new Button(this);
        mainToggle.setAllCaps(false);
        mainToggle.setTextSize(17);
        mainToggle.setTypeface(null,1);
        mainToggle.setTextColor(Color.WHITE);
        mainToggle.setOnClickListener(v->toggleService());
        root.addView(mainToggle,lp(-1,60,0,16));

        LinearLayout listHeader=new LinearLayout(this);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView lh=tv("قائمة الفلاتر",19,Color.WHITE); lh.setTypeface(null,1);
        listHeader.addView(lh,new LinearLayout.LayoutParams(0,40,1));
        TextView count=tv(filters.length+" فلتر",12,Color.rgb(145,155,170));
        listHeader.addView(count,new LinearLayout.LayoutParams(80,40));
        root.addView(listHeader,lp(-1,42,0,4));

        listContainer=new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(listContainer,new LinearLayout.LayoutParams(-1,-2));

        detailContainer=new LinearLayout(this);
        detailContainer.setOrientation(LinearLayout.VERTICAL);
        detailContainer.setVisibility(View.GONE);
        root.addView(detailContainer,new LinearLayout.LayoutParams(-1,-2));

        buildFilterList();

        scroll.addView(root);
        setContentView(scroll);
        updateStateUi();
    }

    private void buildFilterList(){
        listContainer.removeAllViews();
        for(Filter f:filters){
            LinearLayout card=new LinearLayout(this);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(12,8,10,8);
            card.setBackground(rounded(Color.rgb(15,21,30),18));
            card.setOnClickListener(v->openFilter(f));

            View color=new View(this);
            color.setBackground(rounded(Color.rgb(f.r,f.g,f.b),14));
            card.addView(color,new LinearLayout.LayoutParams(58,44));

            LinearLayout texts=new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setGravity(Gravity.CENTER_VERTICAL);
            texts.setPadding(12,0,12,0);

            TextView n=tv(f.name,14,Color.WHITE); n.setTypeface(null,1);
            n.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            texts.addView(n);
            TextView ar=tv(f.ar,11,Color.rgb(145,155,170));
            ar.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            texts.addView(ar);
            card.addView(texts,new LinearLayout.LayoutParams(0,60,1));

            TextView arrow=tv("‹",28,CYAN);
            arrow.setGravity(Gravity.CENTER);
            card.addView(arrow,new LinearLayout.LayoutParams(36,60));

            listContainer.addView(card,lp(-1,78,0,7));
        }
    }

    private void openFilter(Filter f){
        current=f;
        listContainer.setVisibility(View.GONE);
        detailContainer.setVisibility(View.VISIBLE);
        detailContainer.removeAllViews();

        Button back=new Button(this);
        back.setText("‹  كل الفلاتر");
        back.setAllCaps(false);
        back.setTextColor(CYAN);
        back.setTextSize(13);
        back.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        back.setBackground(rounded(Color.TRANSPARENT,0));
        back.setOnClickListener(v->showList());
        detailContainer.addView(back,lp(-1,48,0,3));

        TextView name=tv(f.name,23,Color.WHITE); name.setTypeface(null,1);
        name.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        detailContainer.addView(name,lp(-1,42,0,0));

        selectedTitle=name;

        TextView ar=tv(f.ar,14,CYAN);
        ar.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        detailContainer.addView(ar,lp(-1,28,0,2));
        selectedSub=ar;

        TextView desc=tv(f.description,12,Color.rgb(145,155,170));
        desc.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        detailContainer.addView(desc,lp(-1,32,0,12));

        Button apply=new Button(this);
        apply.setText("تشغيل هذا الفلتر");
        apply.setAllCaps(false);
        apply.setTextSize(16);
        apply.setTypeface(null,1);
        apply.setTextColor(Color.WHITE);
        apply.setBackground(rounded(Color.rgb(0,150,185),21));
        apply.setOnClickListener(v->{
            if(!running) toggleService();
            else sendUpdate();
        });
        detailContainer.addView(apply,lp(-1,58,0,14));

        TextView settings=tv("إعدادات الفلتر",18,Color.WHITE);
        settings.setTypeface(null,1);
        settings.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        detailContainer.addView(settings,lp(-1,36,0,4));

        intensity=slider(detailContainer,"القوة",78);
        contrast=slider(detailContainer,"التباين",f.c);
        saturation=slider(detailContainer,"التشبع",f.s);
        brightness=slider(detailContainer,"السطوع",f.br);
        warmth=slider(detailContainer,"الدفء",f.w);

        intensity.setProgress(78);
    }

    private void showList(){
        detailContainer.setVisibility(View.GONE);
        listContainer.setVisibility(View.VISIBLE);
    }

    private SeekBar slider(LinearLayout root,String label,int value){
        TextView l=tv(label,13,Color.rgb(205,212,222));
        l.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        root.addView(l,lp(-1,26,5,0));

        SeekBar s=new SeekBar(this);
        s.setMax(100);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean fromUser){
                if(running && fromUser) sendUpdate();
            }
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
        root.addView(s,lp(-1,38,0,1));
        return s;
    }

    private void toggleService(){
        if(!Settings.canDrawOverlays(this)){
            openOverlaySettings();
            return;
        }

        if(running){
            running=false;
            stopService(new Intent(this,OverlayService.class));
        }else{
            running=true;
            Intent i=new Intent(this,OverlayService.class);
            i.setAction(OverlayService.ACTION_START);
            putValues(i);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        }
        updateStateUi();
    }

    private void sendUpdate(){
        if(!running || current==null) return;
        Intent i=new Intent(this,OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        putValues(i);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        updateStateUi();
    }

    private void putValues(Intent i){
        if(current==null) current=filters[0];
        i.putExtra("r",current.r);
        i.putExtra("g",current.g);
        i.putExtra("b",current.b);
        i.putExtra("alpha",current.a);
        i.putExtra("intensity",intensity==null?78:intensity.getProgress());
        i.putExtra("contrast",contrast==null?current.c:contrast.getProgress());
        i.putExtra("saturation",saturation==null?current.s:saturation.getProgress());
        i.putExtra("brightness",brightness==null?current.br:brightness.getProgress());
        i.putExtra("warmth",warmth==null?current.w:warmth.getProgress());
    }

    private void updateStateUi(){
        if(mainToggle==null || status==null) return;
        if(running){
            mainToggle.setText("إيقاف الفلتر");
            mainToggle.setBackground(rounded(Color.rgb(190,48,65),22));
            status.setText("الفلتر يعمل الآن");
            dot.setTextColor(Color.rgb(60,235,140));
        }else{
            mainToggle.setText("تشغيل الفلتر");
            mainToggle.setBackground(rounded(Color.rgb(0,150,185),22));
            status.setText("الفلتر متوقف");
            dot.setTextColor(Color.rgb(255,80,90));
        }
    }

    private void openOverlaySettings(){
        try{
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName())));
        }catch(Exception e){
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }
}
