package com.hossam.onestatefilters;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.graphics.PixelFormat;

public class OverlayService extends Service {
    public static final String ACTION_START="com.hossam.onestatefilters.START";
    public static final String ACTION_UPDATE="com.hossam.onestatefilters.UPDATE";
    private static final String CHANNEL="hossam_filters";
    private static final String PREFS="overlay_state";
    private static final String KEY_RUNNING="running";

    private WindowManager wm;
    private FilterView filterView;
    private WindowManager.LayoutParams params;

    public static boolean isRunning(Context c){
        return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
                .getBoolean(KEY_RUNNING,false);
    }

    @Override public void onCreate(){
        super.onCreate();
        createChannel();

        try{
            if(Build.VERSION.SDK_INT>=34){
                startForeground(77,notification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            }else{
                startForeground(77,notification());
            }
        }catch(Exception e){
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_RUNNING,false).apply();
            stopSelf();
            return;
        }

        if(!Settings.canDrawOverlays(this)){
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_RUNNING,false).apply();
            stopSelf();
            return;
        }

        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        createOverlay();
    }

    private void createOverlay(){
        if(filterView!=null) return;

        filterView=new FilterView();
        params=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                |WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                |WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                |WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        params.gravity=Gravity.TOP|Gravity.START;
        params.setTitle("Hossam OneState Full Screen Filter");

        try{
            wm.addView(filterView,params);
        }catch(Exception e){
            filterView=null;
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_RUNNING,false).apply();
            stopSelf();
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(filterView==null) createOverlay();

        if(intent!=null && (ACTION_START.equals(intent.getAction()) || ACTION_UPDATE.equals(intent.getAction()))
                && filterView!=null){
            filterView.setValues(
                intent.getIntExtra("r",18),
                intent.getIntExtra("g",42),
                intent.getIntExtra("b",95),
                intent.getIntExtra("alpha",88),
                intent.getIntExtra("intensity",78),
                intent.getIntExtra("contrast",70),
                intent.getIntExtra("saturation",70),
                intent.getIntExtra("brightness",55),
                intent.getIntExtra("warmth",50)
            );
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_RUNNING,true).apply();
        }
        return START_STICKY;
    }

    @Override public void onDestroy(){
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_RUNNING,false).apply();
        if(wm!=null && filterView!=null){
            try{ wm.removeViewImmediate(filterView); }catch(Exception ignored){}
        }
        filterView=null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i){ return null; }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(
                CHANNEL,"Hossam Filters",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Full screen game filter");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,
            Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);

        if(Build.VERSION.SDK_INT>=26){
            return new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Hossam OneState Filters")
                .setContentText("الفلتر يعمل فوق الشاشة")
                .setContentIntent(pi).setOngoing(true).build();
        }
        return new Notification.Builder(this)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Hossam OneState Filters")
            .setContentText("الفلتر يعمل فوق الشاشة")
            .setContentIntent(pi).setOngoing(true).build();
    }

    private class FilterView extends View{
        private int r=18,g=42,b=95,a=88,intensity=78,contrast=70,saturation=70,brightness=55,warmth=50;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);

        FilterView(){
            super(OverlayService.this);
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        }

        void setValues(int r,int g,int b,int a,int intensity,int contrast,int saturation,int brightness,int warmth){
            this.r=r;this.g=g;this.b=b;this.a=a;this.intensity=intensity;
            this.contrast=contrast;this.saturation=saturation;this.brightness=brightness;this.warmth=warmth;
            postInvalidate();
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float strength=Math.max(.08f,Math.min(1f,intensity/100f));

            // Base tint. TRANSLUCENT window + SRC_OVER lets the game remain visible below.
            int tintAlpha=Math.max(18,Math.min(150,(int)(a*strength)));
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(tintAlpha,r,g,b));
            c.drawRect(0,0,getWidth(),getHeight(),paint);

            // Saturation simulation: warm color wash increases/decreases perceived color.
            float sat=(saturation-50)/50f;
            if(sat>0){
                int sa=Math.min(48,(int)(sat*48*strength));
                c.drawColor(Color.argb(sa,255,255,255));
            }

            // Brightness.
            int bd=brightness-50;
            if(bd>0){
                c.drawColor(Color.argb(Math.min(55,(int)(bd*.55f)),255,255,255));
            }else if(bd<0){
                c.drawColor(Color.argb(Math.min(65,(int)(-bd*.65f)),0,0,0));
            }

            // Warm/cool.
            float warm=(warmth-50)/50f;
            if(warm>.02f){
                c.drawColor(Color.argb(Math.min(58,(int)(warm*58*strength)),255,130,35));
            }else if(warm<-.02f){
                c.drawColor(Color.argb(Math.min(58,(int)(-warm*58*strength)),35,105,255));
            }

            // Vignette.
            int va=Math.max(0,Math.min(120,(int)((contrast-15)*1.15f)));
            int w=getWidth(),h=getHeight();
            if(w>0&&h>0&&va>0){
                RadialGradient rgd=new RadialGradient(
                    w/2f,h/2f,Math.max(w,h)*.80f,
                    new int[]{Color.TRANSPARENT,Color.argb(va,0,0,0)},
                    new float[]{.42f,1f},Shader.TileMode.CLAMP);
                paint.setShader(rgd);
                c.drawRect(0,0,w,h,paint);
                paint.setShader(null);
            }
        }
    }
}
