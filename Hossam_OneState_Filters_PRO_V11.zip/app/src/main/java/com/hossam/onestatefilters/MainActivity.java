package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 10, 16);
    private static final int PANEL = Color.rgb(18, 25, 38);
    private static final int PANEL_2 = Color.rgb(25, 34, 50);
    private static final int BORDER = Color.rgb(58, 72, 92);
    private static final int CYAN = Color.rgb(0, 220, 246);
    private static final int GREEN = Color.rgb(72, 225, 143);
    private static final int RED = Color.rgb(244, 76, 91);
    private static final int MUTED = Color.rgb(158, 171, 190);
    private static final int WHITE = Color.WHITE;

    private LinearLayout content;
    private TextView statusTitle, statusSub, statusDot, permissionValue, mainAction;
    private boolean running;
    private Filter current;
    private SeekBar intensity, contrast, saturation, brightness, warmth;

    static class Filter {
        final String name, ar, description;
        final int r, g, b, alpha, contrast, saturation, brightness, warmth;
        Filter(String name, String ar, String description, int r, int g, int b, int alpha,
               int contrast, int saturation, int brightness, int warmth) {
            this.name = name; this.ar = ar; this.description = description;
            this.r = r; this.g = g; this.b = b; this.alpha = alpha;
            this.contrast = contrast; this.saturation = saturation;
            this.brightness = brightness; this.warmth = warmth;
        }
    }

    private final Filter[] filters = {
        new Filter("NIGHT CINEMATIC", "ليل سينمائي", "أزرق عميق وتباين سينمائي للمشاهد الليلية.", 18,42,95,76,76,64,48,30),
        new Filter("NIGHT VISION", "رؤية ليلية", "يرفع إضاءة المشاهد المظلمة مع تدرج أخضر خفيف لرؤية أوضح أثناء الليل.", 35,180,78,38,45,72,100,30),
        new Filter("SUNSET GOLD", "غروب ذهبي", "دفء برتقالي وذهبي مناسب للغروب واللقطات الدافئة.", 220,92,24,66,68,78,58,88),
        new Filter("MORNING FILM", "صباح فيلمي", "إضاءة صباحية ناعمة مع ألوان طبيعية.", 255,210,150,42,52,60,68,72),
        new Filter("GTA CINEMATIC", "GTA سينمائي", "مظهر قوي للشوارع والمطاردات واللقطات السينمائية.", 76,42,24,62,82,78,50,48),
        new Filter("DARK URBAN", "مدينة داكنة", "سواد أعمق وتباين أعلى للمدينة ليلاً.", 8,14,28,78,88,55,38,28),
        new Filter("EMERALD NIGHT", "ليل زمردي", "درجة زمردية باردة للمشاهد الليلية.", 14,112,76,70,78,82,43,28),
        new Filter("STREET FIRE", "شوارع حارة", "دفء قوي وحضور أعلى للألوان في الحركة.", 178,46,18,62,82,84,50,90),
        new Filter("COLD CITY", "مدينة باردة", "مظهر بارد ونظيف للمدينة.", 24,78,145,64,74,64,48,20),
        new Filter("GOLDEN HOUR", "الساعة الذهبية", "تدرج ذهبي سينمائي للمساء.", 238,156,52,58,64,78,66,92),
        new Filter("MOVIE PRO", "فيلم احترافي", "توازن عام مناسب لمعظم المشاهد.", 58,60,54,54,88,70,52,50),
        new Filter("ULTRA CLEAR", "وضوح فائق", "تباين واضح مع معالجة لونية قوية.", 86,92,110,28,94,66,56,50),
        new Filter("FILM 90s", "فيلم 90s", "طابع فيلمي دافئ مستوحى من أفلام التسعينات.", 118,82,48,54,62,68,48,65)
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        running = OverlayService.isRunning(this);
        buildShell();
        showFilterList();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshState();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, float radius, int stroke, float width) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (width > 0) d.setStroke(dp(width), stroke);
        return d;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        // Keep Android's font padding: it prevents Arabic ascenders/descenders from being clipped.
        v.setIncludeFontPadding(true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        return v;
    }

    private LinearLayout.LayoutParams margins(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private void buildShell() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(24));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(26));
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView brand = text("HOSSAM", 32, CYAN, true);
        brand.setTextDirection(View.TEXT_DIRECTION_LTR);
        brand.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        root.addView(brand, margins(-1, dp(48), 0, 0));

        TextView title = text("OneState Filters", 24, WHITE, true);
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        root.addView(title, margins(-1, dp(40), 0, 2));

        TextView subtitle = text("تحكم احترافي بألوان شاشة OneState", 13, MUTED, false);
        subtitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        root.addView(subtitle, margins(-1, dp(34), 0, 16));

        LinearLayout state = card(PANEL, 18);
        state.setPadding(dp(14), dp(10), dp(14), dp(10));
        state.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        statusTitle = text("الفلتر متوقف", 15, WHITE, true);
        statusSub = text("لا توجد طبقة فوق اللعبة", 11, MUTED, false);
        info.addView(statusTitle, new LinearLayout.LayoutParams(-1, dp(27)));
        info.addView(statusSub, new LinearLayout.LayoutParams(-1, dp(24)));
        state.addView(info, new LinearLayout.LayoutParams(0, dp(54), 1));
        statusDot = text("●", 20, RED, true);
        statusDot.setTextDirection(View.TEXT_DIRECTION_LTR);
        statusDot.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        state.addView(statusDot, new LinearLayout.LayoutParams(dp(34), dp(54)));
        root.addView(state, margins(-1, dp(76), 0, 10));

        LinearLayout permission = card(PANEL, 18);
        permission.setPadding(dp(12), dp(9), dp(9), dp(9));
        permission.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout pinfo = new LinearLayout(this);
        pinfo.setOrientation(LinearLayout.VERTICAL);
        pinfo.setGravity(Gravity.CENTER_VERTICAL);
        pinfo.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        pinfo.addView(text("صلاحية الظهور فوق التطبيقات", 13, WHITE, true), new LinearLayout.LayoutParams(-1, dp(27)));
        permissionValue = text("جارٍ التحقق…", 10, MUTED, false);
        pinfo.addView(permissionValue, new LinearLayout.LayoutParams(-1, dp(23)));
        permission.addView(pinfo, new LinearLayout.LayoutParams(0, dp(50), 1));
        TextView manage = button("إدارة", PANEL_2, CYAN, 12);
        manage.setOnClickListener(v -> openOverlaySettings());
        permission.addView(manage, new LinearLayout.LayoutParams(dp(86), dp(50)));
        root.addView(permission, margins(-1, dp(70), 0, 12));

        mainAction = button("تشغيل الفلتر", CYAN, BG, 16);
        mainAction.setOnClickListener(v -> toggleService());
        root.addView(mainAction, margins(-1, dp(56), 0, 20));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(content, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(root, new ViewGroup.LayoutParams(-1, -1));
        setContentView(scroll);
        refreshState();
    }

    private LinearLayout card(int color, float radius) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setBackground(bg(color, radius, BORDER, 1));
        return v;
    }

    private TextView button(String value, int background, int color, float sp) {
        TextView v = text(value, sp, color, true);
        v.setGravity(Gravity.CENTER);
        v.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        v.setBackground(bg(background, 16, Color.TRANSPARENT, 0));
        v.setClickable(true);
        return v;
    }

    private void section(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.END);
        box.setPadding(dp(2), 0, dp(2), 0);
        TextView t = text(title, 20, WHITE, true);
        TextView s = text(subtitle, 11, MUTED, false);
        box.addView(t, new LinearLayout.LayoutParams(-1, dp(34)));
        box.addView(s, new LinearLayout.LayoutParams(-1, dp(27)));
        content.addView(box, margins(-1, dp(65), 0, 12));
    }

    private void showFilterList() {
        content.removeAllViews();
        section("الفلاتر السينمائية", "اختر اللون ثم افتح إعداداته للتحكم الكامل");
        for (Filter f : filters) addFilterCard(f);
    }

    private void addFilterCard(Filter f) {
        LinearLayout row = card(PANEL, 20);
        row.setPadding(dp(10), dp(10), dp(10), dp(10));
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> showFilterDetails(f));

        // Dedicated color tile: each filter has its own unmistakable color block.
        LinearLayout swatch = new LinearLayout(this);
        swatch.setGravity(Gravity.CENTER);
        swatch.setBackground(bg(Color.rgb(f.r, f.g, f.b), 16, Color.argb(210,255,255,255), 1));
        TextView star = text("✦", 24, WHITE, true);
        star.setTextDirection(View.TEXT_DIRECTION_LTR);
        star.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        swatch.addView(star, new LinearLayout.LayoutParams(-1, -1));
        row.addView(swatch, new LinearLayout.LayoutParams(dp(68), dp(68)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        info.setPadding(dp(14), 0, dp(12), 0);

        TextView en = text(f.name, 15, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        en.setSingleLine(true);
        en.setEllipsize(TextUtils.TruncateAt.END);
        TextView ar = text(f.ar, 13, Color.rgb(190,201,217), true);
        ar.setSingleLine(true);
        ar.setEllipsize(TextUtils.TruncateAt.END);
        TextView hint = text("اضغط لفتح إعدادات الفلتر", 10, MUTED, false);
        hint.setSingleLine(true);
        hint.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(en, new LinearLayout.LayoutParams(-1, dp(25)));
        info.addView(ar, new LinearLayout.LayoutParams(-1, dp(24)));
        info.addView(hint, new LinearLayout.LayoutParams(-1, dp(20)));
        row.addView(info, new LinearLayout.LayoutParams(0, dp(68), 1));

        TextView arrow = text("‹", 28, MUTED, false);
        arrow.setTextDirection(View.TEXT_DIRECTION_LTR);
        arrow.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(30), dp(68)));
        content.addView(row, margins(-1, dp(90), 0, 12));
    }

    private void showFilterDetails(Filter f) {
        current = f;
        content.removeAllViews();

        TextView back = text("‹  العودة إلى كل الفلاتر", 13, CYAN, true);
        back.setClickable(true);
        back.setOnClickListener(v -> showFilterList());
        content.addView(back, margins(-1, dp(42), 0, 10));

        LinearLayout hero = card(PANEL, 20);
        hero.setPadding(dp(12), dp(12), dp(12), dp(12));
        hero.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout swatch = new LinearLayout(this);
        swatch.setGravity(Gravity.CENTER);
        swatch.setBackground(bg(Color.rgb(f.r,f.g,f.b), 16, Color.argb(210,255,255,255), 1));
        TextView star = text("✦", 28, WHITE, true);
        star.setTextDirection(View.TEXT_DIRECTION_LTR);
        star.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        swatch.addView(star, new LinearLayout.LayoutParams(-1,-1));
        hero.addView(swatch, new LinearLayout.LayoutParams(dp(74), dp(74)));

        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        ht.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ht.setPadding(dp(14), 0, dp(6), 0);
        TextView en = text(f.name, 19, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        TextView ar = text(f.ar, 14, CYAN, true);
        ht.addView(en, new LinearLayout.LayoutParams(-1, dp(30)));
        ht.addView(ar, new LinearLayout.LayoutParams(-1, dp(27)));
        hero.addView(ht, new LinearLayout.LayoutParams(0, dp(74), 1));
        content.addView(hero, margins(-1, dp(100), 0, 12));

        TextView desc = text(f.description, 12, MUTED, false);
        desc.setBackground(bg(Color.rgb(13,18,27), 16, BORDER, 1));
        desc.setPadding(dp(14), dp(10), dp(14), dp(10));
        desc.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        content.addView(desc, margins(-1, dp(62), 0, 12));

        TextView apply = button(running && current == f ? "●  الفلتر يعمل الآن" : "تشغيل هذا الفلتر", running && current == f ? GREEN : CYAN, running && current == f ? BG : BG, 16);
        apply.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return; }
            if (!running) startFilter(); else sendUpdate();
        });
        content.addView(apply, margins(-1, dp(56), 0, 10));

        TextView stop = button("إيقاف الفلتر", Color.rgb(54,26,33), RED, 14);
        stop.setOnClickListener(v -> {
            if (running) {
                stopService(new Intent(this, OverlayService.class));
                running = false;
                refreshState();
                showFilterDetails(f);
            }
        });
        content.addView(stop, margins(-1, dp(50), 0, 20));

        section("إعدادات الفلتر", "كل إعداد داخل بطاقة مستقلة لسهولة التحكم");
        intensity = addSlider("قوة التأثير", 78);
        contrast = addSlider("التباين", f.contrast);
        saturation = addSlider("التشبع", f.saturation);
        brightness = addSlider("السطوع", f.brightness);
        warmth = addSlider("الدفء", f.warmth);

        TextView note = text("التعديلات تُرسل مباشرة إلى طبقة الفلتر عند تشغيلها.", 10, MUTED, false);
        note.setBackground(bg(Color.rgb(13,18,27), 14, BORDER, 1));
        note.setPadding(dp(12), dp(8), dp(12), dp(8));
        content.addView(note, margins(-1, dp(44), 4, 0));
    }

    private SeekBar addSlider(String name, int value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(9), dp(14), dp(7));
        box.setBackground(bg(Color.rgb(13,18,27), 16, BORDER, 1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView valueView = text(String.valueOf(value), 11, CYAN, true);
        valueView.setTextDirection(View.TEXT_DIRECTION_LTR);
        valueView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        valueView.setGravity(Gravity.CENTER);
        valueView.setBackground(bg(PANEL_2, 9, Color.TRANSPARENT, 0));
        top.addView(valueView, new LinearLayout.LayoutParams(dp(44), dp(30)));
        TextView label = text(name, 13, WHITE, true);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        top.addView(label, new LinearLayout.LayoutParams(0, dp(30), 1));
        box.addView(top, new LinearLayout.LayoutParams(-1, dp(32)));

        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(value);
        bar.setPadding(dp(2), 0, dp(2), 0);
        bar.setContentDescription(name);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueView.setText(String.valueOf(progress));
                if (fromUser && running) sendUpdate();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(bar, new LinearLayout.LayoutParams(-1, dp(38)));
        content.addView(box, margins(-1, dp(82), 0, 10));
        return bar;
    }

    private void toggleService() {
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return; }
        if (running) {
            stopService(new Intent(this, OverlayService.class));
            running = false;
            refreshState();
        } else startFilter();
    }

    private void startFilter() {
        if (current == null) current = filters[0];
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_START);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 450);
    }

    private void sendUpdate() {
        if (current == null) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 250);
    }

    private void putValues(Intent i) {
        Filter f = current == null ? filters[0] : current;
        i.putExtra("r", f.r); i.putExtra("g", f.g); i.putExtra("b", f.b); i.putExtra("alpha", f.alpha);
        i.putExtra("intensity", intensity == null ? 78 : intensity.getProgress());
        i.putExtra("contrast", contrast == null ? f.contrast : contrast.getProgress());
        i.putExtra("saturation", saturation == null ? f.saturation : saturation.getProgress());
        i.putExtra("brightness", brightness == null ? f.brightness : brightness.getProgress());
        i.putExtra("warmth", warmth == null ? f.warmth : warmth.getProgress());
    }

    private void refreshState() {
        running = OverlayService.isRunning(this);
        if (statusTitle == null) return;
        boolean permission = Settings.canDrawOverlays(this);
        permissionValue.setText(permission ? "مفعّلة • الطبقة جاهزة" : "غير مفعّلة • اضغط إدارة للسماح");
        permissionValue.setTextColor(permission ? GREEN : Color.rgb(255,175,75));
        if (running) {
            statusTitle.setText("الفلتر يعمل الآن");
            statusSub.setText("طبقة الشاشة مفعّلة فوق التطبيقات");
            statusDot.setTextColor(GREEN);
            mainAction.setText("إيقاف الفلتر");
            mainAction.setTextColor(WHITE);
            mainAction.setBackground(bg(Color.rgb(54,26,33), 16, RED, 1));
        } else {
            statusTitle.setText("الفلتر متوقف");
            statusSub.setText("لا توجد طبقة فوق اللعبة");
            statusDot.setTextColor(RED);
            mainAction.setText("تشغيل الفلتر");
            mainAction.setTextColor(BG);
            mainAction.setBackground(bg(CYAN, 16, Color.TRANSPARENT, 0));
        }
    }

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }
}
