package com.hossam.onestatefilters;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String ACTION_UPDATE="com.hossam.onestatefilters.UPDATE";
    static final String CHANNEL="hossam_filters";

    WindowManager wm; FilterView view;

    @Override public void onCreate(){
        super.onCreate();
        channel();
        startForeground(77,notification());
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}

        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        view=new FilterView();

        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(
            -1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;
        wm.addView(view,lp);
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&ACTION_UPDATE.equals(i.getAction())&&view!=null)
            view.values(i.getIntExtra("r",18),i.getIntExtra("g",42),i.getIntExtra("b",95),
                i.getIntExtra("alpha",88),i.getIntExtra("intensity",78),
                i.getIntExtra("contrast",70),i.getIntExtra("warmth",50));
        return START_STICKY;
    }

    void channel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Hossam Filters",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Game filter overlay");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    Notification notification(){
        Intent x=new Intent(this,MainActivity.class);
        PendingIntent p=PendingIntent.getActivity(this,0,x,
            Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
        if(Build.VERSION.SDK_INT>=26)
            return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Hossam OneState Filters").setContentText("فلتر الشاشة يعمل الآن")
                .setContentIntent(p).setOngoing(true).build();
        return new Notification.Builder(this).setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Hossam OneState Filters").setContentText("فلتر الشاشة يعمل الآن")
            .setContentIntent(p).setOngoing(true).build();
    }

    @Override public void onDestroy(){
        if(wm!=null&&view!=null)try{wm.removeView(view);}catch(Exception ignored){}
        view=null;wm=null;super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}

    class FilterView extends View{
        int r=18,g=42,b=95,a=88,intensity=78,contrast=70,warmth=50;
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        FilterView(){super(OverlayService.this);setLayerType(View.LAYER_TYPE_HARDWARE,null);}

        void values(int r,int g,int b,int a,int intensity,int contrast,int warmth){
            this.r=r;this.g=g;this.b=b;this.a=a;this.intensity=intensity;this.contrast=contrast;this.warmth=warmth;
            postInvalidate();
        }

        @Override protected void onDraw(Canvas c){
            float p=Math.max(.08f,Math.min(1f,intensity/100f));
            int aa=Math.max(18,Math.min(175,(int)(a*p)));
            c.drawColor(Color.argb(aa,r,g,b));

            float warm=(warmth-50)/50f;
            if(warm>.03f)c.drawColor(Color.argb((int)(55*warm*p),255,135,45));
            if(warm<-.03f)c.drawColor(Color.argb((int)(55*(-warm)*p),45,115,255));

            int w=getWidth(),h=getHeight();
            if(w>0&&h>0){
                int va=Math.max(0,Math.min(125,contrast-15));
                RadialGradient g=new RadialGradient(w/2f,h/2f,Math.max(w,h)*.78f,
                    new int[]{Color.TRANSPARENT,Color.argb(va,0,0,0)},
                    new float[]{.48f,1f},Shader.TileMode.CLAMP);
                paint.setShader(g);c.drawRect(0,0,w,h,paint);paint.setShader(null);
            }
        }
    }
}
