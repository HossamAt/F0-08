package com.hossam.onestatefilters;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends Activity {
    TextView status, selected, dot;
    Button toggle;
    SeekBar intensity, contrast, saturation, brightness, warmth;
    boolean running=false;
    int r=18,g=42,b=95,a=88;

    static class F {
        String name, ar; int r,g,b,a,c,s,br,w;
        F(String n,String ar,int r,int g,int b,int a,int c,int s,int br,int w){
            this.name=n;this.ar=ar;this.r=r;this.g=g;this.b=b;this.a=a;
            this.c=c;this.s=s;this.br=br;this.w=w;
        }
    }

    final F[] filters={
        new F("Night Cinematic","ليل سينمائي",18,42,95,88,76,64,45,30),
        new F("Sunset Gold","غروب ذهبي",220,92,24,72,68,78,58,88),
        new F("Morning Film","صباح فيلمي",255,210,150,48,52,60,68,72),
        new F("GTA Cinematic","سينمائي",76,42,24,68,82,78,50,48),
        new F("Dark Urban","مدينة داكنة",8,14,28,95,88,55,38,28),
        new F("Emerald Night","ليل زمردي",14,112,76,82,78,82,43,28),
        new F("Street Fire","شوارع حارة",178,46,18,70,82,84,50,90),
        new F("Cold City","مدينة باردة",24,78,145,76,74,64,48,20),
        new F("Golden Hour","الساعة الذهبية",238,156,52,62,64,78,66,92),
        new F("Movie Pro","احترافي",58,60,54,58,88,70,52,50),
        new F("Ultra Clear","وضوح قوي",86,92,110,28,94,66,56,50),
        new F("Film 90s","فيلم قديم",118,82,48,60,62,68,48,65)
    };

    int cyan=Color.rgb(0,220,255), bg=Color.rgb(7,9,14);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        ui();
        choose(filters[0]);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                !=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);
    }

    GradientDrawable box(int c,int rad){
        GradientDrawable d=new GradientDrawable(); d.setColor(c); d.setCornerRadius(rad); return d;
    }

    TextView tv(String s,float z,int c){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(z); t.setTextColor(c);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    LinearLayout.LayoutParams p(int w,int h,int top,int bottom){
        LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(w,h);
        x.setMargins(0,top,0,bottom); return x;
    }

    void ui(){
        ScrollView sc=new ScrollView(this); sc.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,18,20,28);

        TextView brand=tv("HOSSAM",30,cyan); brand.setTypeface(null,1); root.addView(brand);
        TextView title=tv("OneState Filters",24,Color.WHITE); title.setTypeface(null,1); root.addView(title);
        root.addView(tv("فلاتر سينمائية لشاشة اللعبة",13,Color.rgb(150,160,175)),p(-1,32,2,12));

        LinearLayout state=new LinearLayout(this); state.setGravity(Gravity.CENTER_VERTICAL);
        state.setPadding(14,8,14,8); state.setBackground(box(Color.rgb(17,23,32),22));
        dot=tv("●",20,Color.rgb(255,80,90)); state.addView(dot,new LinearLayout.LayoutParams(30,48));
        LinearLayout ss=new LinearLayout(this); ss.setOrientation(LinearLayout.VERTICAL);
        status=tv("الفلاتر متوقفة",15,Color.WHITE); status.setTypeface(null,1); ss.addView(status);
        ss.addView(tv("اختر فلترًا ثم فعّله قبل فتح اللعبة",12,Color.rgb(145,153,166)));
        state.addView(ss,new LinearLayout.LayoutParams(0,56,1)); root.addView(state,p(-1,72,0,10));

        LinearLayout perm=new LinearLayout(this); perm.setPadding(14,6,8,6);
        perm.setGravity(Gravity.CENTER_VERTICAL); perm.setBackground(box(Color.rgb(13,18,26),20));
        perm.addView(tv("صلاحية الظهور فوق التطبيقات",13,Color.WHITE),new LinearLayout.LayoutParams(0,50,1));
        Button pb=new Button(this); pb.setText("إدارة"); pb.setAllCaps(false); pb.setTextColor(cyan);
        pb.setBackground(box(Color.rgb(24,36,48),18)); pb.setOnClickListener(v->permission());
        perm.addView(pb,new LinearLayout.LayoutParams(95,50)); root.addView(perm,p(-1,64,0,10));

        toggle=new Button(this); toggle.setText("تشغيل الفلتر"); toggle.setTextSize(18); toggle.setAllCaps(false);
        toggle.setTypeface(null,1); toggle.setTextColor(Color.WHITE); toggle.setBackground(box(Color.rgb(0,145,175),24));
        toggle.setOnClickListener(v->toggle()); root.addView(toggle,p(-1,64,0,20));

        TextView h=tv("الفلاتر الجاهزة",20,Color.WHITE); h.setTypeface(null,1); root.addView(h,p(-1,34,0,4));
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);

        for(F f:filters){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER); card.setPadding(8,7,8,6); card.setBackground(box(Color.rgb(22,28,38),20));
            View sw=new View(this); sw.setBackground(box(Color.rgb(f.r,f.g,f.b),16));
            card.addView(sw,new LinearLayout.LayoutParams(118,40));
            TextView n=tv(f.name,11,Color.WHITE); n.setGravity(Gravity.CENTER); card.addView(n,new LinearLayout.LayoutParams(118,34));
            card.setOnClickListener(v->choose(f));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(130,86); cp.setMargins(0,0,9,0); row.addView(card,cp);
        }
        hs.addView(row); root.addView(hs,new LinearLayout.LayoutParams(-1,98));

        selected=tv("",18,cyan); selected.setTypeface(null,1); root.addView(selected,p(-1,42,10,3));

        intensity=slider(root,"قوة الفلتر");
        contrast=slider(root,"التباين");
        saturation=slider(root,"التشبع");
        brightness=slider(root,"السطوع");
        warmth=slider(root,"الدفء");

        TextView note=tv("شغّل الفلتر من هنا ثم افتح OneState. الطبقة كاملة الشاشة ولا تستقبل اللمس، لذلك اللعب والتصوير يبقيان طبيعيين.",13,Color.rgb(135,145,160));
        note.setPadding(12,10,12,10); note.setBackground(box(Color.rgb(13,18,26),18)); root.addView(note,p(-1,70,16,0));

        sc.addView(root); setContentView(sc);
    }

    SeekBar slider(LinearLayout root,String name){
        root.addView(tv(name,14,Color.rgb(210,216,226)),p(-1,28,7,0));
        SeekBar s=new SeekBar(this); s.setMax(100); s.setProgress(50);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar x,int v,boolean u){send();}
            public void onStartTrackingTouch(SeekBar x){}
            public void onStopTrackingTouch(SeekBar x){}
        });
        root.addView(s,p(-1,42,0,0)); return s;
    }

    void choose(F f){
        r=f.r;g=f.g;b=f.b;a=f.a; selected.setText("الفلتر الحالي  •  "+f.name+" — "+f.ar);
        intensity.setProgress(78); contrast.setProgress(f.c); saturation.setProgress(f.s);
        brightness.setProgress(f.br); warmth.setProgress(f.w); send();
    }

    void send(){
        if(!running)return;
        Intent i=new Intent(this,OverlayService.class); i.setAction(OverlayService.ACTION_UPDATE);
        i.putExtra("r",r);i.putExtra("g",g);i.putExtra("b",b);i.putExtra("alpha",a);
        i.putExtra("intensity",intensity.getProgress());i.putExtra("contrast",contrast.getProgress());
        i.putExtra("saturation",saturation.getProgress());i.putExtra("brightness",brightness.getProgress());
        i.putExtra("warmth",warmth.getProgress());
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
    }

    void toggle(){
        if(!Settings.canDrawOverlays(this)){permission();return;}
        if(!running){
            running=true; toggle.setText("إيقاف الفلتر"); toggle.setBackground(box(Color.rgb(190,48,65),24));
            status.setText("الفلاتر تعمل الآن"); dot.setTextColor(Color.rgb(60,235,140));
            Intent i=new Intent(this,OverlayService.class);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
            send();
        }else{
            running=false; toggle.setText("تشغيل الفلتر"); toggle.setBackground(box(Color.rgb(0,145,175),24));
            status.setText("الفلاتر متوقفة"); dot.setTextColor(Color.rgb(255,80,90));
            stopService(new Intent(this,OverlayService.class));
        }
    }

    void permission(){
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:"+getPackageName())));
    }
}
