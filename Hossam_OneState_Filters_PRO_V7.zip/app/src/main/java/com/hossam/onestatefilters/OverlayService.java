package com.hossam.onestatefilters;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.graphics.PixelFormat;

public class OverlayService extends Service {
    public static final String ACTION_START = "com.hossam.onestatefilters.START";
    public static final String ACTION_UPDATE = "com.hossam.onestatefilters.UPDATE";
    private static final String CHANNEL = "hossam_filters";
    private static final String PREFS = "overlay_state";
    private static final String KEY_RUNNING = "running";

    private WindowManager wm;
    private FilterView filterView;
    private WindowManager.LayoutParams params;

    public static boolean isRunning(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_RUNNING, false);
    }

    private void setState(boolean value) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, value).apply();
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(77, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(77, notification());
            }
        } catch (Exception e) {
            setState(false);
            stopSelf();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            setState(false);
            stopSelf();
            return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!Settings.canDrawOverlays(this)) {
            setState(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (filterView == null) createOverlay();
        if (filterView != null && intent != null &&
                (ACTION_START.equals(intent.getAction()) || ACTION_UPDATE.equals(intent.getAction()))) {
            filterView.setValues(
                    intent.getIntExtra("r", 18),
                    intent.getIntExtra("g", 42),
                    intent.getIntExtra("b", 95),
                    intent.getIntExtra("alpha", 70),
                    intent.getIntExtra("intensity", 78),
                    intent.getIntExtra("contrast", 70),
                    intent.getIntExtra("saturation", 70),
                    intent.getIntExtra("brightness", 50),
                    intent.getIntExtra("warmth", 50)
            );
            setState(true);
        }
        return START_STICKY;
    }

    private void createOverlay() {
        filterView = new FilterView();
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.setTitle("Hossam OneState Color Filter");
        try {
            wm.addView(filterView, params);
        } catch (Exception e) {
            filterView = null;
            setState(false);
            stopSelf();
        }
    }

    @Override public void onDestroy() {
        setState(false);
        if (wm != null && filterView != null) {
            try { wm.removeViewImmediate(filterView); } catch (Exception ignored) {}
        }
        filterView = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Hossam Filters", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("OneState screen color filter");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Hossam OneState Filters")
                .setContentText("الفلتر يعمل فوق الشاشة")
                .setContentIntent(pi).setOngoing(true).build();
    }

    private class FilterView extends View {
        private int r=18,g=42,b=95,a=70,intensity=78,contrast=70,saturation=70,brightness=50,warmth=50;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FilterView() {
            super(OverlayService.this);
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void setValues(int r,int g,int b,int a,int intensity,int contrast,int saturation,int brightness,int warmth) {
            this.r=r; this.g=g; this.b=b; this.a=a; this.intensity=intensity;
            this.contrast=contrast; this.saturation=saturation; this.brightness=brightness; this.warmth=warmth;
            postInvalidate();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (getWidth() <= 0 || getHeight() <= 0) return;
            float strength = Math.max(0.05f, Math.min(1f, intensity / 100f));

            // Main cinematic tint. Kept deliberately translucent so the game remains clearly visible.
            int tintAlpha = Math.max(10, Math.min(105, Math.round(a * strength)));
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(tintAlpha, r, g, b));
            c.drawRect(0, 0, getWidth(), getHeight(), paint);

            // Warm/cool grade.
            float warm = (warmth - 50) / 50f;
            if (Math.abs(warm) > 0.02f) {
                int wa = Math.min(38, Math.round(Math.abs(warm) * 38f * strength));
                paint.setColor(warm > 0 ? Color.argb(wa,255,128,32) : Color.argb(wa,35,105,255));
                c.drawRect(0,0,getWidth(),getHeight(),paint);
            }

            // Brightness wash.
            int bd = brightness - 50;
            if (bd != 0) {
                int ba = Math.min(30, Math.round(Math.abs(bd) * 0.45f * strength));
                paint.setColor(bd > 0 ? Color.argb(ba,255,255,255) : Color.argb(ba,0,0,0));
                c.drawRect(0,0,getWidth(),getHeight(),paint);
            }

            // Slight saturation boost is represented as a restrained white/black wash, never an opaque layer.
            int sat = saturation - 50;
            if (sat > 0) {
                int sa = Math.min(18, Math.round(sat * 0.32f * strength));
                paint.setColor(Color.argb(sa,255,255,255));
                c.drawRect(0,0,getWidth(),getHeight(),paint);
            }

            // Cinematic vignette.
            int va = Math.max(0, Math.min(75, Math.round((contrast - 35) * 0.9f)));
            if (va > 0) {
                float w = getWidth(), h = getHeight();
                RadialGradient gradient = new RadialGradient(
                        w/2f, h/2f, Math.max(w,h) * 0.78f,
                        new int[]{Color.TRANSPARENT, Color.argb(va,0,0,0)},
                        new float[]{0.45f, 1f}, Shader.TileMode.CLAMP);
                paint.setShader(gradient);
                c.drawRect(0,0,w,h,paint);
                paint.setShader(null);
            }
        }
    }
}
