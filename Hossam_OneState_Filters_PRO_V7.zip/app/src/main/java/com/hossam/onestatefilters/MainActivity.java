package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(6, 8, 13);
    private static final int CARD = Color.rgb(15, 20, 29);
    private static final int CARD_2 = Color.rgb(19, 26, 37);
    private static final int CYAN = Color.rgb(0, 215, 245);
    private static final int MUTED = Color.rgb(151, 162, 178);
    private static final int WHITE = Color.WHITE;

    private LinearLayout root, content;
    private TextView statusTitle, statusSub, statusDot, permissionValue;
    private TextView mainAction;
    private boolean running;
    private Filter current;
    private SeekBar intensity, contrast, saturation, brightness, warmth;

    static class Filter {
        final String name, ar, description;
        final int r, g, b, alpha, contrast, saturation, brightness, warmth;
        Filter(String name, String ar, String description, int r, int g, int b, int alpha,
               int contrast, int saturation, int brightness, int warmth) {
            this.name = name; this.ar = ar; this.description = description;
            this.r = r; this.g = g; this.b = b; this.alpha = alpha;
            this.contrast = contrast; this.saturation = saturation;
            this.brightness = brightness; this.warmth = warmth;
        }
    }

    private final Filter[] filters = {
        new Filter("NIGHT CINEMATIC", "ليل سينمائي", "أزرق عميق وتباين سينمائي للمشاهد الليلية.", 18,42,95,76,76,64,48,30),
        new Filter("SUNSET GOLD", "غروب ذهبي", "دفء برتقالي وذهبي مناسب للغروب واللقطات الدافئة.", 220,92,24,66,68,78,58,88),
        new Filter("MORNING FILM", "صباح فيلمي", "إضاءة صباحية ناعمة مع ألوان طبيعية.", 255,210,150,42,52,60,68,72),
        new Filter("GTA CINEMATIC", "GTA سينمائي", "مظهر قوي للشوارع والمطاردات واللقطات السينمائية.", 76,42,24,62,82,78,50,48),
        new Filter("DARK URBAN", "مدينة داكنة", "سواد أعمق وتباين أعلى للمدينة ليلاً.", 8,14,28,78,88,55,38,28),
        new Filter("EMERALD NIGHT", "ليل زمردي", "درجة زمردية باردة للمشاهد الليلية.", 14,112,76,70,78,82,43,28),
        new Filter("STREET FIRE", "شوارع حارة", "دفء قوي وحضور أعلى للألوان في الحركة.", 178,46,18,62,82,84,50,90),
        new Filter("COLD CITY", "مدينة باردة", "مظهر بارد ونظيف للمدينة.", 24,78,145,64,74,64,48,20),
        new Filter("GOLDEN HOUR", "الساعة الذهبية", "تدرج ذهبي سينمائي للمساء.", 238,156,52,58,64,78,66,92),
        new Filter("MOVIE PRO", "فيلم احترافي", "توازن عام مناسب لمعظم المشاهد.", 58,60,54,54,88,70,52,50),
        new Filter("ULTRA CLEAR", "وضوح فائق", "تباين واضح مع معالجة لونية قوية.", 86,92,110,28,94,66,56,50),
        new Filter("FILM 90s", "فيلم 90s", "طابع فيلمي دافئ مستوحى من أفلام التسعينات.", 118,82,48,54,62,68,48,65)
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        running = OverlayService.isRunning(this);
        buildShell();
        showFilterList();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshState();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        v.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        return v;
    }

    private LinearLayout.LayoutParams size(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private void buildShell() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(20));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(22));
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.END);
        header.setPadding(dp(4), 0, dp(4), 0);

        TextView brand = text("HOSSAM", 31, CYAN, true);
        brand.setTextDirection(View.TEXT_DIRECTION_LTR);
        brand.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        header.addView(brand, size(-1, 40, 0, 2));

        TextView title = text("OneState Filters", 25, WHITE, true);
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        title.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        header.addView(title, size(-1, 34, 0, 2));

        TextView sub = text("فلاتر سينمائية للشاشة • تحكم كامل", 12, MUTED, false);
        header.addView(sub, size(-1, 26, 0, 10));
        root.addView(header, size(-1, -2, 0, 0));

        LinearLayout state = card();
        state.setPadding(dp(12), dp(9), dp(12), dp(9));
        statusDot = text("●", 17, Color.RED, true);
        statusDot.setTextDirection(View.TEXT_DIRECTION_LTR);
        statusDot.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        state.addView(statusDot, new LinearLayout.LayoutParams(dp(34), dp(48)));

        LinearLayout stateText = new LinearLayout(this);
        stateText.setOrientation(LinearLayout.VERTICAL);
        statusTitle = text("الفلتر متوقف", 16, WHITE, true);
        statusSub = text("لا توجد طبقة فوق اللعبة", 11, MUTED, false);
        stateText.addView(statusTitle, size(-1, 25, 0, 1));
        stateText.addView(statusSub, size(-1, 21, 0, 0));
        state.addView(stateText, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(state, size(-1, 68, 0, 9));

        LinearLayout permission = card();
        permission.setPadding(dp(12), dp(6), dp(8), dp(6));
        LinearLayout ptxt = new LinearLayout(this);
        ptxt.setOrientation(LinearLayout.VERTICAL);
        TextView pt = text("صلاحية الظهور فوق التطبيقات", 13, WHITE, true);
        permissionValue = text("جارٍ التحقق…", 10, MUTED, false);
        ptxt.addView(pt, size(-1, 23, 0, 1));
        ptxt.addView(permissionValue, size(-1, 18, 0, 0));
        permission.addView(ptxt, new LinearLayout.LayoutParams(0, 47, 1));

        TextView manage = action("إدارة", CARD_2, CYAN, 12);
        manage.setOnClickListener(v -> openOverlaySettings());
        permission.addView(manage, new LinearLayout.LayoutParams(dp(82), dp(47)));
        root.addView(permission, size(-1, 62, 0, 9));

        mainAction = action("تشغيل الفلتر", CYAN, WHITE, 16);
        mainAction.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mainAction.setOnClickListener(v -> toggleService());
        root.addView(mainAction, size(-1, 58, 0, 15));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(root, new ViewGroup.LayoutParams(-1, -1));
        setContentView(scroll);
        refreshState();
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(bg(CARD, 18));
        return c;
    }

    private TextView action(String label, int background, int color, float sp) {
        TextView v = text(label, sp, color, true);
        v.setGravity(Gravity.CENTER);
        v.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        v.setBackground(bg(background, 18));
        v.setMinHeight(dp(44));
        v.setClickable(true);
        return v;
    }

    private void showFilterList() {
        content.removeAllViews();

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView count = text(filters.length + " فلاتر جاهزة", 11, MUTED, false);
        heading.addView(count, new LinearLayout.LayoutParams(0, dp(34), 1));
        TextView h = text("اختر الفلتر", 20, WHITE, true);
        heading.addView(h, new LinearLayout.LayoutParams(0, dp(34), 1));
        content.addView(heading, size(-1, 38, 0, 7));

        for (Filter f : filters) addFilterCard(f);
    }

    private void addFilterCard(Filter f) {
        LinearLayout row = card();
        row.setPadding(dp(10), dp(9), dp(10), dp(9));
        row.setClickable(true);
        row.setForeground(selectableBackground());
        row.setOnClickListener(v -> showFilterDetails(f));

        View swatch = new View(this);
        swatch.setBackground(bg(Color.rgb(f.r, f.g, f.b), 12));
        row.addView(swatch, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(12), 0, dp(12), 0);

        TextView en = text(f.name, 14, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        en.setEllipsize(TextUtils.TruncateAt.END);
        en.setSingleLine(true);
        TextView ar = text(f.ar, 11, MUTED, false);
        ar.setSingleLine(true);
        ar.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(en, size(-1, 23, 0, 2));
        info.addView(ar, size(-1, 20, 0, 0));
        row.addView(info, new LinearLayout.LayoutParams(0, 52, 1));

        TextView arrow = text("‹", 25, CYAN, true);
        arrow.setTextDirection(View.TEXT_DIRECTION_LTR);
        arrow.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(28), dp(52)));

        content.addView(row, size(-1, 70, 0, 7));
    }

    private android.graphics.drawable.Drawable selectableBackground() {
        if (Build.VERSION.SDK_INT >= 21) return getDrawable(android.R.drawable.list_selector_background);
        return null;
    }

    private void showFilterDetails(Filter f) {
        current = f;
        content.removeAllViews();

        TextView back = text("‹  كل الفلاتر", 13, CYAN, true);
        back.setTextDirection(View.TEXT_DIRECTION_RTL);
        back.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        back.setClickable(true);
        back.setOnClickListener(v -> showFilterList());
        content.addView(back, size(-1, 42, 0, 4));

        LinearLayout hero = card();
        hero.setPadding(dp(14), dp(13), dp(14), dp(13));
        View swatch = new View(this);
        swatch.setBackground(bg(Color.rgb(f.r, f.g, f.b), 14));
        hero.addView(swatch, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        TextView en = text(f.name, 20, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        TextView ar = text(f.ar, 12, CYAN, true);
        ht.addView(en, size(-1, 28, 0, 2));
        ht.addView(ar, size(-1, 22, 0, 0));
        hero.addView(ht, new LinearLayout.LayoutParams(0, 58, 1));
        content.addView(hero, size(-1, 84, 0, 8));

        TextView desc = text(f.description, 12, MUTED, false);
        desc.setBackground(bg(Color.rgb(11, 16, 23), 14));
        desc.setPadding(dp(12), dp(10), dp(12), dp(10));
        desc.setMaxLines(2);
        content.addView(desc, size(-1, 56, 0, 10));

        TextView apply = action(running && current == f ? "الفلتر يعمل الآن" : "تشغيل هذا الفلتر", CYAN, WHITE, 16);
        apply.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                openOverlaySettings();
                return;
            }
            if (!running) startFilter();
            else sendUpdate();
        });
        content.addView(apply, size(-1, 58, 0, 14));

        TextView heading = text("إعدادات الفلتر", 18, WHITE, true);
        content.addView(heading, size(-1, 34, 0, 5));

        intensity = addSlider("قوة التأثير", 78);
        contrast = addSlider("التباين", f.contrast);
        saturation = addSlider("التشبع", f.saturation);
        brightness = addSlider("السطوع", f.brightness);
        warmth = addSlider("الدفء", f.warmth);

        TextView note = text("التغييرات تُرسل مباشرة إلى الطبقة فوق اللعبة عند تشغيل الفلتر.", 10, MUTED, false);
        note.setBackground(bg(Color.rgb(11,16,23), 14));
        note.setPadding(dp(10), dp(8), dp(10), dp(8));
        note.setMaxLines(2);
        content.addView(note, size(-1, 44, 8, 0));
    }

    private SeekBar addSlider(String label, int value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(Color.rgb(12,17,24), 14));
        box.setPadding(dp(12), dp(7), dp(12), dp(4));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView valueView = text(String.valueOf(value), 11, CYAN, true);
        valueView.setTextDirection(View.TEXT_DIRECTION_LTR);
        valueView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        top.addView(valueView, new LinearLayout.LayoutParams(dp(38), dp(22)));
        TextView labelView = text(label, 12, WHITE, true);
        top.addView(labelView, new LinearLayout.LayoutParams(0, dp(22), 1));
        box.addView(top);

        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(value);
        bar.setContentDescription(label);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueView.setText(String.valueOf(progress));
                if (fromUser && running) sendUpdate();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(bar, new LinearLayout.LayoutParams(-1, dp(34)));
        content.addView(box, size(-1, 72, 0, 7));
        return bar;
    }

    private void toggleService() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            return;
        }
        if (running) {
            stopService(new Intent(this, OverlayService.class));
            running = false;
            refreshState();
        } else {
            startFilter();
        }
    }

    private void startFilter() {
        if (current == null) current = filters[0];
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_START);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 350);
    }

    private void sendUpdate() {
        if (current == null) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 200);
    }

    private void putValues(Intent i) {
        Filter f = current == null ? filters[0] : current;
        i.putExtra("r", f.r);
        i.putExtra("g", f.g);
        i.putExtra("b", f.b);
        i.putExtra("alpha", f.alpha);
        i.putExtra("intensity", intensity == null ? 78 : intensity.getProgress());
        i.putExtra("contrast", contrast == null ? f.contrast : contrast.getProgress());
        i.putExtra("saturation", saturation == null ? f.saturation : saturation.getProgress());
        i.putExtra("brightness", brightness == null ? f.brightness : brightness.getProgress());
        i.putExtra("warmth", warmth == null ? f.warmth : warmth.getProgress());
    }

    private void refreshState() {
        running = OverlayService.isRunning(this);
        if (statusTitle == null) return;
        boolean permission = Settings.canDrawOverlays(this);
        permissionValue.setText(permission ? "مفعّلة • جاهزة لتشغيل الطبقة" : "غير مفعّلة • اضغط إدارة للسماح");
        permissionValue.setTextColor(permission ? Color.rgb(75, 225, 145) : Color.rgb(255, 170, 70));
        if (running) {
            statusTitle.setText("الفلتر يعمل الآن");
            statusSub.setText("طبقة الشاشة مفعّلة فوق التطبيقات");
            statusDot.setTextColor(Color.rgb(65, 235, 145));
            mainAction.setText("إيقاف الفلتر");
            mainAction.setBackground(bg(Color.rgb(190, 52, 68), 18));
        } else {
            statusTitle.setText("الفلتر متوقف");
            statusSub.setText("لا توجد طبقة فوق اللعبة");
            statusDot.setTextColor(Color.rgb(255, 80, 90));
            mainAction.setText("تشغيل الفلتر");
            mainAction.setBackground(bg(CYAN, 18));
        }
    }

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }
}
