# Hossam OneState Filters — FIXED v3

This version fixes the crash:
ClassNotFoundException: com.hossam.onestatefilters.MainActivity

The project is Java-only, so there is no missing Kotlin MainActivity.

The app has:
- Filter selection inside the app
- 12 ready-made cinematic filters
- Intensity, contrast, saturation, brightness and warmth controls
- Start/stop overlay button
- No floating control box over the game
- The overlay is NOT_TOUCHABLE, so it does not block OneState controls

The overlay provides a visual color/tone/vignette treatment. A normal Android overlay cannot increase the real pixel resolution/sharpness of another app.
