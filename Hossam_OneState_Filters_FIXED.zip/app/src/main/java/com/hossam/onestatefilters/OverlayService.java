package com.hossam.onestatefilters;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {

    public static final String ACTION_START =
            "com.hossam.onestatefilters.START";

    public static final String ACTION_UPDATE =
            "com.hossam.onestatefilters.UPDATE";

    private WindowManager windowManager;
    private FilterOverlayView overlay;

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager =
                (WindowManager) getSystemService(WINDOW_SERVICE);

        overlay = new FilterOverlayView(this);

        WindowManager.LayoutParams params =
                new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        android.graphics.PixelFormat.TRANSLUCENT
                );

        params.gravity = Gravity.CENTER;

        windowManager.addView(overlay, params);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            if (overlay != null) {
                overlay.update(
                        intent.getIntExtra("r", 25),
                        intent.getIntExtra("g", 55),
                        intent.getIntExtra("b", 95),
                        intent.getIntExtra("alpha", 62),
                        intent.getIntExtra("intensity", 70),
                        intent.getIntExtra("contrast", 70),
                        intent.getIntExtra("saturation", 60),
                        intent.getIntExtra("brightness", 50),
                        intent.getIntExtra("warmth", 50)
                );
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlay != null && windowManager != null) {
            try {
                windowManager.removeView(overlay);
            } catch (Exception ignored) {
            }
        }
        overlay = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static class FilterOverlayView extends View {

        private int r = 25, g = 55, b = 95;
        private int baseAlpha = 62;
        private int intensity = 70;
        private int contrast = 70;
        private int warmth = 50;

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FilterOverlayView(OverlayService service) {
            super(service);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            // Explicitly transparent from the start.
            setBackgroundColor(Color.TRANSPARENT);
        }

 
        void update(int r, int g, int b, int alpha,
                    int intensity, int contrast,
                    int saturation, int brightness, int warmth) {

            this.r = r;
            this.g = g;
            this.b = b;
            this.baseAlpha = alpha;
            this.intensity = intensity;
            this.contrast = contrast;
            this.warmth = warmth;

            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            if (getWidth() <= 0 || getHeight() <= 0) return;

            float power = Math.max(0f, Math.min(1f, intensity / 100f));

            // Keep the overlay subtle and never turn it into a black rectangle.
            int a = Math.max(
                    0,
                    Math.min(115, Math.round(baseAlpha * power))
            );

            if (a > 0) {
                canvas.drawColor(Color.argb(a, r, g, b));
            }

            float warm = (warmth - 50f) / 50f;

            if (Math.abs(warm) > 0.05f) {
                int warmAlpha =
                        Math.min(42, Math.round(32f * Math.abs(warm) * power));

                if (warm > 0) {
                    canvas.drawColor(
                            Color.argb(warmAlpha, 255, 145, 55)
                    );
                } else {
                    canvas.drawColor(
                            Color.argb(warmAlpha, 50, 110, 255)
                    );
                }
            }

            int vignetteAlpha =
                    Math.max(0, Math.min(75, contrast - 35));

            if (vignetteAlpha > 0) {
                RadialGradient gradient =
                        new RadialGradient(
                                getWidth() / 2f,
                                getHeight() / 2f,
                                Math.max(getWidth(), getHeight()) * 0.72f,
                                new int[]{
                                        Color.TRANSPARENT,
                                        Color.argb(
                                                vignetteAlpha,
                                                0, 0, 0
                                        )
                                },
                                new float[]{0.48f, 1f},
                                Shader.TileMode.CLAMP
                        );

                paint.setShader(gradient);
                canvas.drawRect(
                        0, 0, getWidth(), getHeight(), paint
                );
                paint.setShader(null);
            }
        }
    }
}
