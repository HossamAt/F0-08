package com.hossam.onestatefilters;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView status;
    private TextView selected;
    private Button toggle;

    private SeekBar intensity, contrast, saturation, brightness, warmth;

    private boolean overlayRunning = false;
    private Filter current;

    private final List<Filter> filters = Arrays.asList(
        new Filter("Night Cinematic", 25, 55, 95, 62, 72, 58, 45, 32),
        new Filter("Sunset Gold", 220, 105, 35, 52, 64, 74, 58, 84),
        new Filter("Morning Film", 255, 220, 170, 34, 52, 55, 65, 70),
        new Filter("GTA Cinematic", 75, 45, 30, 50, 80, 72, 50, 48),
        new Filter("Dark Urban", 12, 18, 28, 70, 84, 50, 38, 28),
        new Filter("Emerald Night", 20, 105, 75, 56, 74, 76, 43, 34),
        new Filter("Street Fire", 160, 55, 25, 50, 78, 80, 48, 80),
        new Filter("Cold City", 35, 80, 135, 53, 72, 62, 48, 20),
        new Filter("Golden Hour", 235, 165, 70, 46, 62, 72, 64, 90),
        new Filter("Movie Pro", 65, 65, 55, 40, 82, 65, 52, 50),
        new Filter("Ultra Clear", 90, 95, 105, 12, 90, 62, 55, 50),
        new Filter("Film 90s", 115, 85, 55, 44, 58, 64, 49, 64)
    );

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        buildUi();
        selectFilter(filters.get(0));
    }

    private void buildUi() {
        int white = Color.WHITE;
        int muted = Color.rgb(170, 178, 190);
        int cyan = Color.rgb(0, 217, 255);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(9, 11, 16));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(24));
        scroll.addView(root);

        TextView brand = text("HOSSAM", 30, cyan, true);
        root.addView(brand);

        TextView title = text("OneState Filters", 23, white, true);
        root.addView(title);

        TextView subtitle = text(
            "اختار الفلتر والإعدادات من هنا، ثم شغّله فوق اللعبة.",
            14, muted, false
        );
        root.addView(subtitle);

        status = text("الحالة: متوقف", 15, muted, true);
        root.addView(status, marginTop(12));

        Button permission = button("السماح بالظهور فوق التطبيقات");
        permission.setOnClickListener(v -> openPermission());
        root.addView(permission, marginTop(12));

        toggle = button("تشغيل الفلتر");
        toggle.setOnClickListener(v -> toggleOverlay());
        root.addView(toggle, marginTop(8));

        TextView filterTitle = text("الفلاتر الجاهزة", 20, white, true);
        root.addView(filterTitle, marginTop(22));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout filterRow = new LinearLayout(this);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(filterRow);
        root.addView(hsv, marginTop(8));

        for (Filter f : filters) {
            Button b = button(f.name);
            b.setTextSize(11);
            b.setMinHeight(dp(70));
            b.setMinWidth(dp(155));
            b.setBackgroundColor(Color.rgb(f.r, f.g, f.b));
            b.setOnClickListener(v -> selectFilter(f));

            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(155), dp(70));
            p.setMargins(0, 0, dp(8), 0);
            filterRow.addView(b, p);
        }

        selected = text("الفلتر الحالي", 18, cyan, true);
        root.addView(selected, marginTop(12));

        intensity = addSlider(root, "قوة الفلتر", 70);
        contrast = addSlider(root, "التباين", 70);
        saturation = addSlider(root, "التشبع", 60);
        brightness = addSlider(root, "السطوع", 50);
        warmth = addSlider(root, "الدفء", 50);

        TextView note = text(
            "ملاحظة: الفلتر هنا طبقة لونية سينمائية فوق اللعبة. لا تغيّر دقة اللعبة الأصلية أو عدد البكسلات.",
            12, Color.rgb(125, 135, 148), false
        );
        root.addView(note, marginTop(16));

        SeekBar.OnSeekBarChangeListener listener =
            new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    sendUpdate();
                }
                public void onStartTrackingTouch(SeekBar s) {}
                public void onStopTrackingTouch(SeekBar s) {}
            };

        intensity.setOnSeekBarChangeListener(listener);
        contrast.setOnSeekBarChangeListener(listener);
        saturation.setOnSeekBarChangeListener(listener);
        brightness.setOnSeekBarChangeListener(listener);
        warmth.setOnSeekBarChangeListener(listener);

        setContentView(scroll);
    }

    private SeekBar addSlider(LinearLayout root, String label, int value) {
        TextView t = text(label, 14, Color.WHITE, false);
        root.addView(t, marginTop(12));

        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(value);
        root.addView(s);
        return s;
    }

    private void selectFilter(Filter f) {
        current = f;
        selected.setText("الفلتر الحالي: " + f.name);

        intensity.setProgress(f.intensity);
        contrast.setProgress(f.contrast);
        saturation.setProgress(f.saturation);
        brightness.setProgress(f.brightness);
        warmth.setProgress(f.warmth);

        sendUpdate();
    }

    private void toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openPermission();
            return;
        }

        if (!overlayRunning) {
            overlayRunning = true;
            Intent i = new Intent(this, OverlayService.class);
            i.setAction(OverlayService.ACTION_START);
            startService(i);

            toggle.setText("إيقاف الفلتر");
            status.setText("الحالة: الفلتر يعمل فوق اللعبة");
            sendUpdate();
        } else {
            overlayRunning = false;
            stopService(new Intent(this, OverlayService.class));

            toggle.setText("تشغيل الفلتر");
            status.setText("الحالة: متوقف");
        }
    }

    private void sendUpdate() {
        if (!overlayRunning || current == null) return;

        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);

        i.putExtra("r", current.r);
        i.putExtra("g", current.g);
        i.putExtra("b", current.b);
        i.putExtra("alpha", current.alpha);
        i.putExtra("intensity", intensity.getProgress());
        i.putExtra("contrast", contrast.getProgress());
        i.putExtra("saturation", saturation.getProgress());
        i.putExtra("brightness", brightness.getProgress());
        i.putExtra("warmth", warmth.getProgress());

        startService(i);
    }

    private void openPermission() {
        try {
            Intent i = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams marginTop(int dp) {
        LinearLayout.LayoutParams p =
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
        p.topMargin = dp(dp);
        return p;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class Filter {
        String name;
        int r, g, b, alpha;
        int intensity, contrast, saturation, brightness, warmth;

        Filter(String name, int r, int g, int b, int alpha,
               int intensity, int contrast, int brightness, int warmth) {
            this.name = name;
            this.r = r;
            this.g = g;
            this.b = b;
            this.alpha = alpha;
            this.intensity = intensity;
            this.contrast = contrast;
            this.saturation = saturation;
            this.brightness = brightness;
            this.warmth = warmth;
        }
    }
}
