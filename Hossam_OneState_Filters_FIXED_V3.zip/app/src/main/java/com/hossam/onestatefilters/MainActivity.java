package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView statusText;
    private TextView selectedText;
    private Button toggleButton;

    private SeekBar intensity;
    private SeekBar contrast;
    private SeekBar saturation;
    private SeekBar brightness;
    private SeekBar warmth;

    private boolean overlayRunning = false;

    private int filterR = 25;
    private int filterG = 55;
    private int filterB = 95;
    private int filterAlpha = 65;

    private static class Filter {
        final String name;
        final int r, g, b, alpha;
        final int contrast, saturation, brightness, warmth;

        Filter(String name, int r, int g, int b, int alpha,
               int contrast, int saturation, int brightness, int warmth) {
            this.name = name;
            this.r = r;
            this.g = g;
            this.b = b;
            this.alpha = alpha;
            this.contrast = contrast;
            this.saturation = saturation;
            this.brightness = brightness;
            this.warmth = warmth;
        }
    }

    private final Filter[] filters = {
        new Filter("Night Cinematic", 25, 55, 95, 65, 70, 55, 45, 35),
        new Filter("Sunset Gold", 220, 105, 35, 58, 62, 68, 55, 82),
        new Filter("Morning Film", 255, 220, 170, 38, 48, 52, 62, 68),
        new Filter("GTA Cinematic", 75, 45, 30, 52, 78, 70, 50, 45),
        new Filter("Dark Urban", 12, 18, 28, 72, 82, 48, 38, 30),
        new Filter("Emerald Night", 20, 105, 75, 58, 72, 72, 42, 35),
        new Filter("Street Fire", 160, 55, 25, 50, 76, 78, 48, 78),
        new Filter("Cold City", 35, 80, 135, 55, 70, 58, 48, 22),
        new Filter("Golden Hour", 235, 165, 70, 48, 60, 70, 62, 88),
        new Filter("Movie Pro", 65, 65, 55, 42, 80, 62, 52, 50),
        new Filter("Ultra Clear", 90, 95, 105, 18, 88, 58, 55, 50),
        new Filter("Film 90s", 115, 85, 55, 45, 55, 60, 48, 62)
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        buildUi();

        selectFilter(filters[0]);
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, 5, 0, 5);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setAllCaps(false);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(8, 9, 13));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 28);

        TextView logo = text("HOSSAM", 30, Color.rgb(0, 217, 255));
        logo.setTypeface(null, 1);
        root.addView(logo);

        TextView title = text("OneState Filters", 23, Color.WHITE);
        title.setTypeface(null, 1);
        root.addView(title);

        statusText = text("الفلاتر متوقفة", 15, Color.LTGRAY);
        root.addView(statusText);

        Button permission = button("السماح بالظهور فوق التطبيقات");
        permission.setOnClickListener(v -> openOverlayPermission());
        root.addView(permission, params(1, 56, 0, 18, 0, 0));

        toggleButton = button("تشغيل الفلتر فوق اللعبة");
        toggleButton.setOnClickListener(v -> toggleOverlay());
        root.addView(toggleButton, params(1, 58, 0, 8, 0, 0));

        TextView presetTitle = text("الفلاتر الجاهزة", 20, Color.WHITE);
        presetTitle.setTypeface(null, 1);
        root.addView(presetTitle, params(1, -2, 0, 22, 0, 5));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);

        LinearLayout filterRow = new LinearLayout(this);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);

        for (Filter f : filters) {
            Button b = button(f.name);
            b.setTextColor(Color.WHITE);
            b.setBackgroundColor(Color.rgb(f.r, f.g, f.b));
            b.setOnClickListener(v -> selectFilter(f));

            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(180, 82);
            p.setMargins(0, 0, 10, 0);
            filterRow.addView(b, p);
        }

        hsv.addView(filterRow);
        root.addView(hsv, params(1, 90, 0, 0, 0, 0));

        selectedText = text("", 18, Color.rgb(0, 217, 255));
        selectedText.setTypeface(null, 1);
        root.addView(selectedText, params(1, -2, 0, 12, 0, 12));

        intensity = addSlider(root, "قوة الفلتر");
        contrast = addSlider(root, "التباين");
        saturation = addSlider(root, "التشبع");
        brightness = addSlider(root, "السطوع");
        warmth = addSlider(root, "الدفء");

        TextView note = text(
            "اختر الفلتر واضبط الإعدادات هنا أولاً، ثم اضغط تشغيل وافتح OneState. الطبقة لا تستقبل اللمس حتى لا تعيق التحكم باللعبة.",
            13, Color.rgb(150, 155, 165)
        );
        root.addView(note, params(1, -2, 0, 18, 0, 0));

        scroll.addView(root);
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams params(
            int widthWeight, int height, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p;
        if (height == -2) {
            p = new LinearLayout.LayoutParams(0, height, widthWeight);
        } else {
            p = new LinearLayout.LayoutParams(
                    widthWeight == 1 ? LinearLayout.LayoutParams.MATCH_PARENT : widthWeight,
                    height
            );
        }
        p.setMargins(l, t, r, b);
        return p;
    }

    private SeekBar addSlider(LinearLayout root, String label) {
        root.addView(text(label, 15, Color.WHITE));

        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(50);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                sendSettings();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        root.addView(bar, params(1, 48, 0, 0, 0, 4));
        return bar;
    }

    private void selectFilter(Filter f) {
        filterR = f.r;
        filterG = f.g;
        filterB = f.b;
        filterAlpha = f.alpha;

        selectedText.setText("الفلتر الحالي: " + f.name);

        intensity.setProgress(70);
        contrast.setProgress(f.contrast);
        saturation.setProgress(f.saturation);
        brightness.setProgress(f.brightness);
        warmth.setProgress(f.warmth);

        sendSettings();
    }

    private void sendSettings() {
        if (!overlayRunning) return;

        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);

        i.putExtra("r", filterR);
        i.putExtra("g", filterG);
        i.putExtra("b", filterB);
        i.putExtra("alpha", filterAlpha);
        i.putExtra("intensity", intensity.getProgress());
        i.putExtra("contrast", contrast.getProgress());
        i.putExtra("saturation", saturation.getProgress());
        i.putExtra("brightness", brightness.getProgress());
        i.putExtra("warmth", warmth.getProgress());

        startService(i);
    }

    private void toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            return;
        }

        if (!overlayRunning) {
            overlayRunning = true;
            toggleButton.setText("إيقاف الفلتر");
            statusText.setText("الفلاتر تعمل فوق اللعبة");
            startService(new Intent(this, OverlayService.class));
            sendSettings();
        } else {
            overlayRunning = false;
            toggleButton.setText("تشغيل الفلتر فوق اللعبة");
            statusText.setText("الفلاتر متوقفة");
            stopService(new Intent(this, OverlayService.class));
        }
    }

    private void openOverlayPermission() {
        Intent i = new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())
        );
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
