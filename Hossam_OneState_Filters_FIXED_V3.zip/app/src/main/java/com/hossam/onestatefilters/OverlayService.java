package com.hossam.onestatefilters;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {

    public static final String ACTION_UPDATE =
            "com.hossam.onestatefilters.UPDATE";

    private WindowManager windowManager;
    private FilterView filterView;

    @Override
    public void onCreate() {
        super.onCreate();

        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        filterView = new FilterView();

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
        );

        lp.gravity = Gravity.TOP | Gravity.START;

        windowManager.addView(filterView, lp);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            filterView.setValues(
                    intent.getIntExtra("r", 25),
                    intent.getIntExtra("g", 55),
                    intent.getIntExtra("b", 95),
                    intent.getIntExtra("alpha", 65),
                    intent.getIntExtra("intensity", 70),
                    intent.getIntExtra("contrast", 50),
                    intent.getIntExtra("saturation", 50),
                    intent.getIntExtra("brightness", 50),
                    intent.getIntExtra("warmth", 50)
            );
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (windowManager != null && filterView != null) {
            try {
                windowManager.removeView(filterView);
            } catch (Exception ignored) {
            }
        }
        filterView = null;
        windowManager = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static class FilterView extends View {

        private int r = 25, g = 55, b = 95;
        private int alpha = 65;
        private int intensity = 70;
        private int contrast = 50;
        private int warmth = 50;

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FilterView() {
            super(null);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void setValues(int r, int g, int b, int alpha,
                       int intensity, int contrast,
                       int saturation, int brightness, int warmth) {
            this.r = r;
            this.g = g;
            this.b = b;
            this.alpha = alpha;
            this.intensity = intensity;
            this.contrast = contrast;
            this.warmth = warmth;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float power = Math.max(0f, Math.min(1f, intensity / 100f));

            int a = Math.max(0, Math.min(150, (int)(alpha * power)));

            canvas.drawColor(Color.argb(a, r, g, b));

            float warm = (warmth - 50) / 50f;

            if (warm > 0.03f) {
                int wa = (int)(35f * warm * power);
                canvas.drawColor(Color.argb(wa, 255, 145, 55));
            } else if (warm < -0.03f) {
                int wa = (int)(35f * (-warm) * power);
                canvas.drawColor(Color.argb(wa, 50, 120, 255));
            }

            int w = getWidth();
            int h = getHeight();

            if (w > 0 && h > 0) {
                float radius = Math.max(w, h) * 0.72f;
                int va = Math.max(0, Math.min(120, contrast - 25));

                RadialGradient gradient = new RadialGradient(
                        w / 2f,
                        h / 2f,
                        radius,
                        new int[] {
                                Color.TRANSPARENT,
                                Color.argb(va, 0, 0, 0)
                        },
                        new float[] {0.52f, 1f},
                        Shader.TileMode.CLAMP
                );

                paint.setShader(gradient);
                canvas.drawRect(0, 0, w, h, paint);
                paint.setShader(null);
            }
        }
    }
}
