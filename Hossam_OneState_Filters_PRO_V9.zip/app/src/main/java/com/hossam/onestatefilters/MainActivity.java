package com.hossam.onestatefilters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 10, 16);
    private static final int PANEL = Color.rgb(18, 24, 35);
    private static final int PANEL_2 = Color.rgb(22, 30, 43);
    private static final int BORDER = Color.rgb(55, 67, 84);
    private static final int CYAN = Color.rgb(0, 218, 246);
    private static final int GREEN = Color.rgb(73, 224, 143);
    private static final int RED = Color.rgb(244, 76, 91);
    private static final int MUTED = Color.rgb(157, 169, 186);
    private static final int WHITE = Color.WHITE;

    private LinearLayout root, content;
    private TextView statusTitle, statusSub, statusDot, permissionValue, mainAction;
    private boolean running;
    private Filter current;
    private SeekBar intensity, contrast, saturation, brightness, warmth;

    static class Filter {
        final String name, ar, description;
        final int r, g, b, alpha, contrast, saturation, brightness, warmth;
        Filter(String name, String ar, String description, int r, int g, int b, int alpha,
               int contrast, int saturation, int brightness, int warmth) {
            this.name = name; this.ar = ar; this.description = description;
            this.r = r; this.g = g; this.b = b; this.alpha = alpha;
            this.contrast = contrast; this.saturation = saturation;
            this.brightness = brightness; this.warmth = warmth;
        }
    }

    private final Filter[] filters = {
        new Filter("NIGHT CINEMATIC", "ليل سينمائي", "أزرق عميق وتباين سينمائي للمشاهد الليلية.", 18,42,95,76,76,64,48,30),
        new Filter("SUNSET GOLD", "غروب ذهبي", "دفء برتقالي وذهبي مناسب للغروب واللقطات الدافئة.", 220,92,24,66,68,78,58,88),
        new Filter("MORNING FILM", "صباح فيلمي", "إضاءة صباحية ناعمة مع ألوان طبيعية.", 255,210,150,42,52,60,68,72),
        new Filter("GTA CINEMATIC", "GTA سينمائي", "مظهر قوي للشوارع والمطاردات واللقطات السينمائية.", 76,42,24,62,82,78,50,48),
        new Filter("DARK URBAN", "مدينة داكنة", "سواد أعمق وتباين أعلى للمدينة ليلاً.", 8,14,28,78,88,55,38,28),
        new Filter("EMERALD NIGHT", "ليل زمردي", "درجة زمردية باردة للمشاهد الليلية.", 14,112,76,70,78,82,43,28),
        new Filter("STREET FIRE", "شوارع حارة", "دفء قوي وحضور أعلى للألوان في الحركة.", 178,46,18,62,82,84,50,90),
        new Filter("COLD CITY", "مدينة باردة", "مظهر بارد ونظيف للمدينة.", 24,78,145,64,74,64,48,20),
        new Filter("GOLDEN HOUR", "الساعة الذهبية", "تدرج ذهبي سينمائي للمساء.", 238,156,52,58,64,78,66,92),
        new Filter("MOVIE PRO", "فيلم احترافي", "توازن عام مناسب لمعظم المشاهد.", 58,60,54,54,88,70,52,50),
        new Filter("ULTRA CLEAR", "وضوح فائق", "تباين واضح مع معالجة لونية قوية.", 86,92,110,28,94,66,56,50),
        new Filter("FILM 90s", "فيلم 90s", "طابع فيلمي دافئ مستوحى من أفلام التسعينات.", 118,82,48,54,62,68,48,65)
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        running = OverlayService.isRunning(this);
        buildShell();
        showFilterList();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshState();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, float radius, int strokeColor, float strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private TextView label(String value, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private void buildShell() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(28));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Premium header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER_HORIZONTAL);
        header.setPadding(dp(4), dp(4), dp(4), 0);

        TextView brand = label("HOSSAM", 34, CYAN, true);
        brand.setTextDirection(View.TEXT_DIRECTION_LTR);
        brand.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        header.addView(brand, lp(-1, 44, 0, 2));

        TextView title = label("OneState Filters", 25, WHITE, true);
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        header.addView(title, lp(-1, 34, 0, 4));

        TextView sub = label("فلتر شاشتك بأسلوب سينمائي احترافي", 13, MUTED, false);
        sub.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        header.addView(sub, lp(-1, 26, 0, 18));
        root.addView(header, lp(-1, -2, 0, 0));

        // Service status panel
        LinearLayout state = panel(PANEL);
        state.setPadding(dp(14), dp(12), dp(14), dp(12));
        state.setGravity(Gravity.CENTER_VERTICAL);
        state.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout stateInfo = new LinearLayout(this);
        stateInfo.setOrientation(LinearLayout.VERTICAL);
        stateInfo.setGravity(Gravity.CENTER_VERTICAL);
        stateInfo.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        statusTitle = label("الفلتر متوقف", 16, WHITE, true);
        statusSub = label("لا توجد طبقة فوق اللعبة", 11, MUTED, false);
        stateInfo.addView(statusTitle, new LinearLayout.LayoutParams(-1, dp(25)));
        stateInfo.addView(statusSub, new LinearLayout.LayoutParams(-1, dp(20)));
        state.addView(stateInfo, new LinearLayout.LayoutParams(0, dp(49), 1));

        statusDot = label("●", 22, RED, true);
        statusDot.setTextDirection(View.TEXT_DIRECTION_LTR);
        statusDot.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        state.addView(statusDot, new LinearLayout.LayoutParams(dp(38), dp(49)));
        root.addView(state, lp(-1, 76, 0, 10));

        // Overlay permission
        LinearLayout permission = panel(PANEL);
        permission.setPadding(dp(14), dp(10), dp(10), dp(10));
        permission.setGravity(Gravity.CENTER_VERTICAL);
        permission.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout ptxt = new LinearLayout(this);
        ptxt.setOrientation(LinearLayout.VERTICAL);
        ptxt.setGravity(Gravity.CENTER_VERTICAL);
        ptxt.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView pt = label("الظهور فوق التطبيقات", 13, WHITE, true);
        permissionValue = label("جارٍ التحقق…", 10, MUTED, false);
        ptxt.addView(pt, new LinearLayout.LayoutParams(-1, dp(23)));
        ptxt.addView(permissionValue, new LinearLayout.LayoutParams(-1, dp(18)));
        permission.addView(ptxt, new LinearLayout.LayoutParams(0, dp(49), 1));
        TextView manage = button("إدارة", PANEL_2, CYAN, 12);
        manage.setOnClickListener(v -> openOverlaySettings());
        permission.addView(manage, new LinearLayout.LayoutParams(dp(88), dp(49)));
        root.addView(permission, lp(-1, 70, 0, 12));

        mainAction = button("تشغيل الفلتر", CYAN, WHITE, 16);
        mainAction.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mainAction.setOnClickListener(v -> toggleService());
        root.addView(mainAction, lp(-1, 58, 0, 20));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(root, new ViewGroup.LayoutParams(-1, -1));
        setContentView(scroll);
        refreshState();
    }

    private LinearLayout panel(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(rounded(color, 20, BORDER, 1));
        c.setClipToOutline(true);
        return c;
    }

    private TextView button(String value, int background, int color, float sp) {
        TextView v = label(value, sp, color, true);
        v.setGravity(Gravity.CENTER);
        v.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        v.setBackground(rounded(background, 16, Color.TRANSPARENT, 0));
        v.setClickable(true);
        return v;
    }

    private TextView sectionTitle(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.END);
        box.setPadding(dp(4), 0, dp(4), 0);
        TextView t = label(title, 20, WHITE, true);
        TextView s = label(subtitle, 11, MUTED, false);
        box.addView(t, new LinearLayout.LayoutParams(-1, dp(29)));
        box.addView(s, new LinearLayout.LayoutParams(-1, dp(22)));
        content.addView(box, lp(-1, 56, 0, 12));
        return t;
    }

    private void showFilterList() {
        content.removeAllViews();
        sectionTitle("الفلاتر السينمائية", "اختر فلترًا للدخول إلى إعداداته والتحكم به");
        for (Filter f : filters) addFilterCard(f);
    }

    private void addFilterCard(Filter f) {
        // Each filter gets its own large colored square, exactly like the reference style.
        LinearLayout row = panel(PANEL);
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setClickable(true);
        row.setOnClickListener(v -> showFilterDetails(f));

        LinearLayout colorBox = new LinearLayout(this);
        colorBox.setGravity(Gravity.CENTER);
        colorBox.setBackground(rounded(Color.rgb(f.r, f.g, f.b), 18, Color.argb(180,255,255,255), 1));
        TextView icon = label("✦", 24, Color.WHITE, true);
        icon.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        colorBox.addView(icon, new LinearLayout.LayoutParams(-1, -1));
        row.addView(colorBox, new LinearLayout.LayoutParams(dp(68), dp(68)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        info.setPadding(dp(16), 0, dp(12), 0);

        TextView en = label(f.name, 15, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        en.setSingleLine(true);
        en.setEllipsize(TextUtils.TruncateAt.END);
        TextView ar = label(f.ar, 12, Color.rgb(182,192,207), false);
        ar.setSingleLine(true);
        ar.setEllipsize(TextUtils.TruncateAt.END);
        TextView hint = label("اضغط للضبط والتفعيل", 10, MUTED, false);
        info.addView(en, new LinearLayout.LayoutParams(-1, dp(25)));
        info.addView(ar, new LinearLayout.LayoutParams(-1, dp(21)));
        info.addView(hint, new LinearLayout.LayoutParams(-1, dp(18)));
        row.addView(info, new LinearLayout.LayoutParams(0, dp(68), 1));

        TextView arrow = label("‹", 27, MUTED, false);
        arrow.setTextDirection(View.TEXT_DIRECTION_LTR);
        arrow.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(26), dp(68)));

        content.addView(row, lp(-1, 92, 0, 10));
    }

    private void showFilterDetails(Filter f) {
        current = f;
        content.removeAllViews();

        TextView back = label("‹  العودة إلى كل الفلاتر", 13, CYAN, true);
        back.setTextDirection(View.TEXT_DIRECTION_RTL);
        back.setClickable(true);
        back.setOnClickListener(v -> showFilterList());
        content.addView(back, lp(-1, 42, 0, 10));

        LinearLayout hero = panel(PANEL);
        hero.setPadding(dp(14), dp(14), dp(14), dp(14));
        hero.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout colorBox = new LinearLayout(this);
        colorBox.setGravity(Gravity.CENTER);
        colorBox.setBackground(rounded(Color.rgb(f.r, f.g, f.b), 18, Color.argb(190,255,255,255), 1));
        TextView icon = label("✦", 27, WHITE, true);
        icon.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        colorBox.addView(icon, new LinearLayout.LayoutParams(-1, -1));
        hero.addView(colorBox, new LinearLayout.LayoutParams(dp(72), dp(72)));

        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        ht.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ht.setPadding(dp(16), 0, dp(6), 0);
        TextView en = label(f.name, 20, WHITE, true);
        en.setTextDirection(View.TEXT_DIRECTION_LTR);
        en.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        TextView ar = label(f.ar, 13, CYAN, true);
        ht.addView(en, new LinearLayout.LayoutParams(-1, dp(28)));
        ht.addView(ar, new LinearLayout.LayoutParams(-1, dp(23)));
        hero.addView(ht, new LinearLayout.LayoutParams(0, dp(72), 1));
        content.addView(hero, lp(-1, 102, 0, 12));

        TextView desc = label(f.description, 12, MUTED, false);
        desc.setBackground(rounded(Color.rgb(13,18,27), 16, BORDER, 1));
        desc.setPadding(dp(14), dp(11), dp(14), dp(11));
        desc.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        content.addView(desc, lp(-1, 58, 0, 14));

        TextView apply = button(running && current == f ? "الفلتر يعمل الآن" : "تشغيل هذا الفلتر", running && current == f ? GREEN : CYAN, running && current == f ? BG : WHITE, 16);
        apply.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                openOverlaySettings();
                return;
            }
            if (!running) startFilter(); else sendUpdate();
        });
        content.addView(apply, lp(-1, 58, 0, 12));

        TextView stop = button("إيقاف الفلتر", Color.rgb(54, 26, 33), RED, 14);
        stop.setOnClickListener(v -> {
            if (running) {
                stopService(new Intent(this, OverlayService.class));
                running = false;
                refreshState();
                showFilterDetails(f);
            }
        });
        content.addView(stop, lp(-1, 50, 0, 20));

        sectionTitle("إعدادات اللون", "عدّل التأثير ثم اتركه يعمل فوق OneState");
        intensity = addSlider("قوة التأثير", 78);
        contrast = addSlider("التباين", f.contrast);
        saturation = addSlider("التشبع", f.saturation);
        brightness = addSlider("السطوع", f.brightness);
        warmth = addSlider("الدفء", f.warmth);

        TextView note = label("تتزامن التعديلات مباشرة مع طبقة الفلتر عند تشغيلها.", 10, MUTED, false);
        note.setBackground(rounded(Color.rgb(13,18,27), 14, BORDER, 1));
        note.setPadding(dp(12), dp(9), dp(12), dp(9));
        content.addView(note, lp(-1, 42, 8, 0));
    }

    private SeekBar addSlider(String name, int value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(7));
        box.setBackground(rounded(Color.rgb(13,18,27), 16, BORDER, 1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView valueView = label(String.valueOf(value), 11, CYAN, true);
        valueView.setTextDirection(View.TEXT_DIRECTION_LTR);
        valueView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        valueView.setBackground(rounded(PANEL_2, 10, Color.TRANSPARENT, 0));
        top.addView(valueView, new LinearLayout.LayoutParams(dp(42), dp(28)));
        TextView labelView = label(name, 13, WHITE, true);
        top.addView(labelView, new LinearLayout.LayoutParams(0, dp(28), 1));
        box.addView(top);

        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(value);
        bar.setContentDescription(name);
        bar.setPadding(0, 0, 0, 0);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueView.setText(String.valueOf(progress));
                if (fromUser && running) sendUpdate();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(bar, new LinearLayout.LayoutParams(-1, dp(36)));
        content.addView(box, lp(-1, 78, 0, 9));
        return bar;
    }

    private void toggleService() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            return;
        }
        if (running) {
            stopService(new Intent(this, OverlayService.class));
            running = false;
            refreshState();
        } else {
            startFilter();
        }
    }

    private void startFilter() {
        if (current == null) current = filters[0];
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_START);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 450);
    }

    private void sendUpdate() {
        if (current == null) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        putValues(i);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        new Handler().postDelayed(this::refreshState, 250);
    }

    private void putValues(Intent i) {
        Filter f = current == null ? filters[0] : current;
        i.putExtra("r", f.r);
        i.putExtra("g", f.g);
        i.putExtra("b", f.b);
        i.putExtra("alpha", f.alpha);
        i.putExtra("intensity", intensity == null ? 78 : intensity.getProgress());
        i.putExtra("contrast", contrast == null ? f.contrast : contrast.getProgress());
        i.putExtra("saturation", saturation == null ? f.saturation : saturation.getProgress());
        i.putExtra("brightness", brightness == null ? f.brightness : brightness.getProgress());
        i.putExtra("warmth", warmth == null ? f.warmth : warmth.getProgress());
    }

    private void refreshState() {
        running = OverlayService.isRunning(this);
        if (statusTitle == null) return;
        boolean permission = Settings.canDrawOverlays(this);
        permissionValue.setText(permission ? "مفعّلة • جاهزة لتشغيل الطبقة" : "غير مفعّلة • اضغط إدارة للسماح");
        permissionValue.setTextColor(permission ? GREEN : Color.rgb(255, 175, 75));
        if (running) {
            statusTitle.setText("الفلتر يعمل الآن");
            statusSub.setText("طبقة الشاشة مفعّلة فوق التطبيقات");
            statusDot.setTextColor(GREEN);
            mainAction.setText("إيقاف الفلتر");
            mainAction.setBackground(rounded(Color.rgb(54,26,33), 16, RED, 1));
        } else {
            statusTitle.setText("الفلتر متوقف");
            statusSub.setText("لا توجد طبقة فوق اللعبة");
            statusDot.setTextColor(RED);
            mainAction.setText("تشغيل الفلتر");
            mainAction.setBackground(rounded(CYAN, 16, Color.TRANSPARENT, 0));
        }
    }

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }
}
